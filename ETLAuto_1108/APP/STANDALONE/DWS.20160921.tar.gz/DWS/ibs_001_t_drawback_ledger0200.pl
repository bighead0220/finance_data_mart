#!/usr/bin/perl

use strict;     # Declare using Perl strict syntax
use DBI;        # If you are using other package, declare here

# ------------ Variable Section ------------
my ${AUTO_HOME} = $ENV{"AUTO_HOME"};

my ${WML_DB} = $ENV{"AUTO_WML_DB"};
if ( !defined(${WML_DB}) ) {
    ${WML_DB} = "WML";
}
my ${WTL_DB} = $ENV{"AUTO_WTL_DB"};
if ( !defined(${WTL_DB}) ) {
    ${WTL_DB} = "WTL";
}
my ${WMLVIEW_DB} = $ENV{"AUTO_WMLVIEW_DB"};
if ( !defined(${WMLVIEW_DB}) ) {
    ${WMLVIEW_DB} = "WMLVIEW";
}
my ${WTLVIEW_DB} = $ENV{"AUTO_WTLVIEW_DB"};
if ( !defined(${WTLVIEW_DB}) ) {
    ${WTLVIEW_DB} = "WTLVIEW";
}

my ${NULL_DATE} = "1900-01-02";
my ${MIN_DATE} = "1900-01-01";
my ${MAX_DATE} = "2100-12-31";

my ${LOGON_FILE} = "${AUTO_HOME}/etc/VERTICA_LOGON";
my ${LOGON_STR};
my ${CONTROL_FILE};
my ${TX_DATE};
my ${TX_DATE_YYYYMMDD};
my ${TX_MON_DAY_MMDD};

# ------------ VSQL function ------------
sub run_vsql_command
{
  #my $rc = open(VSQL, "${LOGON_STR}");
  my $rc = open(VSQL, "|vsql -h 22.224.65.2 -p 5433 -d CPCIMDB -U dwpsbc -w dwpsbc2016");

  unless ($rc) {
      print "Could not invoke VSQL command
";
      return -1;
  }

# ------ Below are VSQL scripts ----------
  print VSQL <<ENDOFINPUT;

\\set ON_ERROR_STOP on

--Step0:
DELETE FROM dw_sdata.IBS_001_T_DRAWBACK_LEDGER WHERE start_dt>=DATE('${TX_DATE_YYYYMMDD}');
UPDATE dw_sdata.IBS_001_T_DRAWBACK_LEDGER SET end_dt=DATE('2100-12-31') WHERE end_dt>=DATE('${TX_DATE_YYYYMMDD}') AND end_dt<>DATE('2100-12-31');

--Step1:
CREATE LOCAL TEMPORARY TABLE  T_216 ON COMMIT PRESERVE ROWS AS SELECT * FROM dw_sdata.IBS_001_T_DRAWBACK_LEDGER WHERE 1=0;

--Step2:
INSERT  INTO T_216 (
  SERIAL_NO,
  TRAN_DATE,
  CLT_SEQNO,
  HOST_SEQNO,
  TRAN_INST,
  CURR_TYPE1,
  DRAWBACK_AMT1,
  DRAWBACK_AMT2,
  CURR_TYPE2,
  CSTM_FEE1,
  CSTM_FEE2,
  PAY_AMT,
  FOR_FEE1,
  FOR_FEE2,
  EUR_PRC,
  GBP_PRC,
  DRAWBACK_AMT3,
  CONSUME_COUNTRY,
  CURR_TYPE3,
  CERT_NO,
  CONSUME_AMT,
  CONSUME_DATE,
  LEAVE_DATE,
  CSTM_NAME,
  CSTM_COUNTRY,
  PASSPORT,
  PAPER_NO,
  PHONE,
  TRAN_TLR,
  TRAN_STMP,
  AUTH_TLR,
  SND_TLR,
  SND_DATE,
  SND_INST,
  CLR_TLR,
  CLR_DATE,
  CLR_INST,
  LST_TRAN_TLR,
  LST_TRAN_DATE,
  FLAG,
  IN_ACC,
  CURR_TYPE,
  IN_AMT,
  IN_DATE,
  IN_FEE,
  INCLT_SEQNO,
  start_dt,
  end_dt)
SELECT
  N.SERIAL_NO,
  N.TRAN_DATE,
  N.CLT_SEQNO,
  N.HOST_SEQNO,
  N.TRAN_INST,
  N.CURR_TYPE1,
  N.DRAWBACK_AMT1,
  N.DRAWBACK_AMT2,
  N.CURR_TYPE2,
  N.CSTM_FEE1,
  N.CSTM_FEE2,
  N.PAY_AMT,
  N.FOR_FEE1,
  N.FOR_FEE2,
  N.EUR_PRC,
  N.GBP_PRC,
  N.DRAWBACK_AMT3,
  N.CONSUME_COUNTRY,
  N.CURR_TYPE3,
  N.CERT_NO,
  N.CONSUME_AMT,
  N.CONSUME_DATE,
  N.LEAVE_DATE,
  N.CSTM_NAME,
  N.CSTM_COUNTRY,
  N.PASSPORT,
  N.PAPER_NO,
  N.PHONE,
  N.TRAN_TLR,
  N.TRAN_STMP,
  N.AUTH_TLR,
  N.SND_TLR,
  N.SND_DATE,
  N.SND_INST,
  N.CLR_TLR,
  N.CLR_DATE,
  N.CLR_INST,
  N.LST_TRAN_TLR,
  N.LST_TRAN_DATE,
  N.FLAG,
  N.IN_ACC,
  N.CURR_TYPE,
  N.IN_AMT,
  N.IN_DATE,
  N.IN_FEE,
  N.INCLT_SEQNO,
  DATE('${TX_DATE_YYYYMMDD}'),
  DATE('2100-12-31')
FROM 
 (SELECT
  COALESCE(SERIAL_NO, '' ) AS SERIAL_NO ,
  COALESCE(TRAN_DATE, 0 ) AS TRAN_DATE ,
  COALESCE(CLT_SEQNO, '' ) AS CLT_SEQNO ,
  COALESCE(HOST_SEQNO, 0 ) AS HOST_SEQNO ,
  COALESCE(TRAN_INST, '' ) AS TRAN_INST ,
  COALESCE(CURR_TYPE1, '' ) AS CURR_TYPE1 ,
  COALESCE(DRAWBACK_AMT1, 0 ) AS DRAWBACK_AMT1 ,
  COALESCE(DRAWBACK_AMT2, 0 ) AS DRAWBACK_AMT2 ,
  COALESCE(CURR_TYPE2, '' ) AS CURR_TYPE2 ,
  COALESCE(CSTM_FEE1, 0 ) AS CSTM_FEE1 ,
  COALESCE(CSTM_FEE2, 0 ) AS CSTM_FEE2 ,
  COALESCE(PAY_AMT, 0 ) AS PAY_AMT ,
  COALESCE(FOR_FEE1, 0 ) AS FOR_FEE1 ,
  COALESCE(FOR_FEE2, 0 ) AS FOR_FEE2 ,
  COALESCE(EUR_PRC, 0 ) AS EUR_PRC ,
  COALESCE(GBP_PRC, 0 ) AS GBP_PRC ,
  COALESCE(DRAWBACK_AMT3, 0 ) AS DRAWBACK_AMT3 ,
  COALESCE(CONSUME_COUNTRY, '' ) AS CONSUME_COUNTRY ,
  COALESCE(CURR_TYPE3, '' ) AS CURR_TYPE3 ,
  COALESCE(CERT_NO, '' ) AS CERT_NO ,
  COALESCE(CONSUME_AMT, 0 ) AS CONSUME_AMT ,
  COALESCE(CONSUME_DATE, 0 ) AS CONSUME_DATE ,
  COALESCE(LEAVE_DATE, 0 ) AS LEAVE_DATE ,
  COALESCE(CSTM_NAME, '' ) AS CSTM_NAME ,
  COALESCE(CSTM_COUNTRY, '' ) AS CSTM_COUNTRY ,
  COALESCE(PASSPORT, '' ) AS PASSPORT ,
  COALESCE(PAPER_NO, '' ) AS PAPER_NO ,
  COALESCE(PHONE, '' ) AS PHONE ,
  COALESCE(TRAN_TLR, '' ) AS TRAN_TLR ,
  COALESCE(TRAN_STMP, '' ) AS TRAN_STMP ,
  COALESCE(AUTH_TLR, '' ) AS AUTH_TLR ,
  COALESCE(SND_TLR, '' ) AS SND_TLR ,
  COALESCE(SND_DATE, 0 ) AS SND_DATE ,
  COALESCE(SND_INST, '' ) AS SND_INST ,
  COALESCE(CLR_TLR, '' ) AS CLR_TLR ,
  COALESCE(CLR_DATE, 0 ) AS CLR_DATE ,
  COALESCE(CLR_INST, '' ) AS CLR_INST ,
  COALESCE(LST_TRAN_TLR, '' ) AS LST_TRAN_TLR ,
  COALESCE(LST_TRAN_DATE, 0 ) AS LST_TRAN_DATE ,
  COALESCE(FLAG, '' ) AS FLAG ,
  COALESCE(IN_ACC, '' ) AS IN_ACC ,
  COALESCE(CURR_TYPE, '' ) AS CURR_TYPE ,
  COALESCE(IN_AMT, 0 ) AS IN_AMT ,
  COALESCE(IN_DATE, 0 ) AS IN_DATE ,
  COALESCE(IN_FEE, 0 ) AS IN_FEE ,
  COALESCE(INCLT_SEQNO, '' ) AS INCLT_SEQNO 
 FROM  dw_tdata.IBS_001_T_DRAWBACK_LEDGER_${TX_DATE_YYYYMMDD}) N
LEFT JOIN
 (SELECT 
  SERIAL_NO ,
  TRAN_DATE ,
  CLT_SEQNO ,
  HOST_SEQNO ,
  TRAN_INST ,
  CURR_TYPE1 ,
  DRAWBACK_AMT1 ,
  DRAWBACK_AMT2 ,
  CURR_TYPE2 ,
  CSTM_FEE1 ,
  CSTM_FEE2 ,
  PAY_AMT ,
  FOR_FEE1 ,
  FOR_FEE2 ,
  EUR_PRC ,
  GBP_PRC ,
  DRAWBACK_AMT3 ,
  CONSUME_COUNTRY ,
  CURR_TYPE3 ,
  CERT_NO ,
  CONSUME_AMT ,
  CONSUME_DATE ,
  LEAVE_DATE ,
  CSTM_NAME ,
  CSTM_COUNTRY ,
  PASSPORT ,
  PAPER_NO ,
  PHONE ,
  TRAN_TLR ,
  TRAN_STMP ,
  AUTH_TLR ,
  SND_TLR ,
  SND_DATE ,
  SND_INST ,
  CLR_TLR ,
  CLR_DATE ,
  CLR_INST ,
  LST_TRAN_TLR ,
  LST_TRAN_DATE ,
  FLAG ,
  IN_ACC ,
  CURR_TYPE ,
  IN_AMT ,
  IN_DATE ,
  IN_FEE ,
  INCLT_SEQNO 
 FROM dw_sdata.IBS_001_T_DRAWBACK_LEDGER 
 WHERE END_DT = DATE('2100-12-31') ) T
ON N.SERIAL_NO = T.SERIAL_NO
WHERE
(T.SERIAL_NO IS NULL)
 OR N.TRAN_DATE<>T.TRAN_DATE
 OR N.CLT_SEQNO<>T.CLT_SEQNO
 OR N.HOST_SEQNO<>T.HOST_SEQNO
 OR N.TRAN_INST<>T.TRAN_INST
 OR N.CURR_TYPE1<>T.CURR_TYPE1
 OR N.DRAWBACK_AMT1<>T.DRAWBACK_AMT1
 OR N.DRAWBACK_AMT2<>T.DRAWBACK_AMT2
 OR N.CURR_TYPE2<>T.CURR_TYPE2
 OR N.CSTM_FEE1<>T.CSTM_FEE1
 OR N.CSTM_FEE2<>T.CSTM_FEE2
 OR N.PAY_AMT<>T.PAY_AMT
 OR N.FOR_FEE1<>T.FOR_FEE1
 OR N.FOR_FEE2<>T.FOR_FEE2
 OR N.EUR_PRC<>T.EUR_PRC
 OR N.GBP_PRC<>T.GBP_PRC
 OR N.DRAWBACK_AMT3<>T.DRAWBACK_AMT3
 OR N.CONSUME_COUNTRY<>T.CONSUME_COUNTRY
 OR N.CURR_TYPE3<>T.CURR_TYPE3
 OR N.CERT_NO<>T.CERT_NO
 OR N.CONSUME_AMT<>T.CONSUME_AMT
 OR N.CONSUME_DATE<>T.CONSUME_DATE
 OR N.LEAVE_DATE<>T.LEAVE_DATE
 OR N.CSTM_NAME<>T.CSTM_NAME
 OR N.CSTM_COUNTRY<>T.CSTM_COUNTRY
 OR N.PASSPORT<>T.PASSPORT
 OR N.PAPER_NO<>T.PAPER_NO
 OR N.PHONE<>T.PHONE
 OR N.TRAN_TLR<>T.TRAN_TLR
 OR N.TRAN_STMP<>T.TRAN_STMP
 OR N.AUTH_TLR<>T.AUTH_TLR
 OR N.SND_TLR<>T.SND_TLR
 OR N.SND_DATE<>T.SND_DATE
 OR N.SND_INST<>T.SND_INST
 OR N.CLR_TLR<>T.CLR_TLR
 OR N.CLR_DATE<>T.CLR_DATE
 OR N.CLR_INST<>T.CLR_INST
 OR N.LST_TRAN_TLR<>T.LST_TRAN_TLR
 OR N.LST_TRAN_DATE<>T.LST_TRAN_DATE
 OR N.FLAG<>T.FLAG
 OR N.IN_ACC<>T.IN_ACC
 OR N.CURR_TYPE<>T.CURR_TYPE
 OR N.IN_AMT<>T.IN_AMT
 OR N.IN_DATE<>T.IN_DATE
 OR N.IN_FEE<>T.IN_FEE
 OR N.INCLT_SEQNO<>T.INCLT_SEQNO
;

--Step3:
UPDATE dw_sdata.IBS_001_T_DRAWBACK_LEDGER P 
SET End_Dt=DATE('${TX_DATE_YYYYMMDD}')
FROM T_216
WHERE P.End_Dt=DATE('2100-12-31')
AND P.SERIAL_NO=T_216.SERIAL_NO
;

--Step4:
INSERT  INTO dw_sdata.IBS_001_T_DRAWBACK_LEDGER SELECT * FROM T_216;

COMMIT;

ENDOFINPUT

  close(VSQL);

  my $RET_CODE = $? >> 8;

  if ( $RET_CODE == 0 ) {
      return 0;
  }
  else {
      return 1;
  }
}

# ------------ main function ------------
sub main
{
   my $ret;
   open(LOGONFILE_H, "${LOGON_FILE}");
   ${LOGON_STR} = <LOGONFILE_H>;
   close(LOGONFILE_H);
   
   # Get the decoded logon string
   my($user,$passwd) = split(',',${LOGON_STR}); 
   #my $decodepasswd = `${AUTO_HOME}/bin/IceCode.exe -d "$passwd" "$user"`;                     
   #${LOGON_STR} = "|vsql -h 192.168.2.44 -p 5433 -d CPCIMDB -U ".$user." -w ".$decodepasswd;

   # Call vsql command to load data
   $ret = run_vsql_command();

   print "run_vsql_command() = $ret";
   return $ret;
}

# ------------ program section ------------
if ( $#ARGV < 0 ) {
   print "Usage: [perl ������ Control_File] (Control_File format: dir.jobnameYYYYMMDD or sysname_jobname_YYYYMMDD.dir) 
";
   print "
";
   exit(1);
}

# Get the first argument
${CONTROL_FILE} = $ARGV[0];

if (${CONTROL_FILE} =~/[0-9]{8}($|\.)/) {
   ${TX_DATE_YYYYMMDD} = substr($&,0,8);
}
else{
   print "Usage: [perl ������ Control_File] (Control_File format: dir.jobnameYYYYMMDD or sysname_jobname_YYYYMMDD.dir) 
";
   print "
";
   exit(1);
}

${TX_MON_DAY_MMDD} = substr(${TX_DATE_YYYYMMDD}, length(${TX_DATE_YYYYMMDD})-4,4);
${TX_DATE} = substr(${TX_DATE_YYYYMMDD}, 0, 4)."-".substr(${TX_DATE_YYYYMMDD}, 4, 2)."-".substr(${TX_DATE_YYYYMMDD}, 6, 2);
open(STDERR, ">&STDOUT");

my $ret = main();

exit($ret);
