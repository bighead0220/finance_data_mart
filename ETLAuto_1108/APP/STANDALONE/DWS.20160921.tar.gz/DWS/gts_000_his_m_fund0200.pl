#!/usr/bin/perl

use strict;     # Declare using Perl strict syntax
use DBI;        # If you are using other package, declare here

# ------------ Variable Section ------------
my ${AUTO_HOME} = $ENV{"AUTO_HOME"};

my ${WML_DB} = $ENV{"AUTO_WML_DB"};
if ( !defined(${WML_DB}) ) {
    ${WML_DB} = "WML";
}
my ${WTL_DB} = $ENV{"AUTO_WTL_DB"};
if ( !defined(${WTL_DB}) ) {
    ${WTL_DB} = "WTL";
}
my ${WMLVIEW_DB} = $ENV{"AUTO_WMLVIEW_DB"};
if ( !defined(${WMLVIEW_DB}) ) {
    ${WMLVIEW_DB} = "WMLVIEW";
}
my ${WTLVIEW_DB} = $ENV{"AUTO_WTLVIEW_DB"};
if ( !defined(${WTLVIEW_DB}) ) {
    ${WTLVIEW_DB} = "WTLVIEW";
}

my ${NULL_DATE} = "1900-01-02";
my ${MIN_DATE} = "1900-01-01";
my ${MAX_DATE} = "2100-12-31";

my ${LOGON_FILE} = "${AUTO_HOME}/etc/VERTICA_LOGON";
my ${LOGON_STR};
my ${CONTROL_FILE};
my ${TX_DATE};
my ${TX_DATE_YYYYMMDD};
my ${TX_MON_DAY_MMDD};

# ------------ VSQL function ------------
sub run_vsql_command
{
  #my $rc = open(VSQL, "${LOGON_STR}");
  my $rc = open(VSQL, "|vsql -h 22.224.65.2 -p 5433 -d CPCIMDB -U dwpsbc -w dwpsbc2016");

  unless ($rc) {
      print "Could not invoke VSQL command
";
      return -1;
  }

# ------ Below are VSQL scripts ----------
  print VSQL <<ENDOFINPUT;

\\set ON_ERROR_STOP on

DELETE FROM dw_sdata.GTS_000_HIS_M_FUND WHERE etl_dt=DATE('${TX_DATE_YYYYMMDD}');                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      
INSERT  INTO dw_sdata.GTS_000_HIS_M_FUND(                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             
  PARTNO ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  EXCH_DATE ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  ACCT_NO ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  CURRENCY_ID ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  LAST_BAL ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  LAST_CAN_USE ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  CURR_BAL ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  CURR_CAN_USE ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  CURR_CAN_GET ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  LAST_B_MARGIN ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  LAST_M_MARGIN ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  LAST_RESERVE ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  OUT_BAL ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  IN_BAL ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  ENTR_BUY ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  REAL_BUY ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  REAL_SELL ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  ENTR_RESERVE ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  REAL_RESERVE ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  ENTR_MARGIN ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  REAL_B_MARGIN ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  REAL_M_MARGIN ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  BASE_MARGIN ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  LAST_BASE_MARGIN ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  DELI_PREPARE ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  LAST_DELI_PREPARE ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  DELI_MARGIN ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  LAST_DELI_MARGIN ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  ENTR_EXCH_FARE ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  REAL_B_EXCH_FARE ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  REAL_M_EXCH_FARE ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  OTHER_FARE ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  PAY_BREACH ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  TAKE_BREACH ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  COV_SURPLUS ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  MARK_SURPLUS ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  FLOAT_SURPLUS ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  LAST_LONG_FROZ ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  DAY_LONG_FROZ ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  LAST_FORWARD_FROZ ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  DAY_FORWARD_FROZ ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  INTE_INTEGRAL ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  PUNI_INTEGRAL ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  WAIT_INCR_INTE ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  WAIT_INCR_INTE_TAX ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  DAY_INCR_INTE ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  DAY_INCR_INTE_TAX ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  LAST_TAKE_MARGIN ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  DAY_TAKE_MARGIN ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  LAST_STOR_FARE_FROZ ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  DAY_STOR_FARE_FROZ ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
  etl_dt                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              
)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
SELECT                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
  COALESCE(PARTNO, 0 ) AS PARTNO ,
  COALESCE(EXCH_DATE, '' ) AS EXCH_DATE ,
  COALESCE(ACCT_NO, '' ) AS ACCT_NO ,
  COALESCE(CURRENCY_ID, '' ) AS CURRENCY_ID ,
  COALESCE(LAST_BAL, 0 ) AS LAST_BAL ,
  COALESCE(LAST_CAN_USE, 0 ) AS LAST_CAN_USE ,
  COALESCE(CURR_BAL, 0 ) AS CURR_BAL ,
  COALESCE(CURR_CAN_USE, 0 ) AS CURR_CAN_USE ,
  COALESCE(CURR_CAN_GET, 0 ) AS CURR_CAN_GET ,
  COALESCE(LAST_B_MARGIN, 0 ) AS LAST_B_MARGIN ,
  COALESCE(LAST_M_MARGIN, 0 ) AS LAST_M_MARGIN ,
  COALESCE(LAST_RESERVE, 0 ) AS LAST_RESERVE ,
  COALESCE(OUT_BAL, 0 ) AS OUT_BAL ,
  COALESCE(IN_BAL, 0 ) AS IN_BAL ,
  COALESCE(ENTR_BUY, 0 ) AS ENTR_BUY ,
  COALESCE(REAL_BUY, 0 ) AS REAL_BUY ,
  COALESCE(REAL_SELL, 0 ) AS REAL_SELL ,
  COALESCE(ENTR_RESERVE, 0 ) AS ENTR_RESERVE ,
  COALESCE(REAL_RESERVE, 0 ) AS REAL_RESERVE ,
  COALESCE(ENTR_MARGIN, 0 ) AS ENTR_MARGIN ,
  COALESCE(REAL_B_MARGIN, 0 ) AS REAL_B_MARGIN ,
  COALESCE(REAL_M_MARGIN, 0 ) AS REAL_M_MARGIN ,
  COALESCE(BASE_MARGIN, 0 ) AS BASE_MARGIN ,
  COALESCE(LAST_BASE_MARGIN, 0 ) AS LAST_BASE_MARGIN ,
  COALESCE(DELI_PREPARE, 0 ) AS DELI_PREPARE ,
  COALESCE(LAST_DELI_PREPARE, 0 ) AS LAST_DELI_PREPARE ,
  COALESCE(DELI_MARGIN, 0 ) AS DELI_MARGIN ,
  COALESCE(LAST_DELI_MARGIN, 0 ) AS LAST_DELI_MARGIN ,
  COALESCE(ENTR_EXCH_FARE, 0 ) AS ENTR_EXCH_FARE ,
  COALESCE(REAL_B_EXCH_FARE, 0 ) AS REAL_B_EXCH_FARE ,
  COALESCE(REAL_M_EXCH_FARE, 0 ) AS REAL_M_EXCH_FARE ,
  COALESCE(OTHER_FARE, 0 ) AS OTHER_FARE ,
  COALESCE(PAY_BREACH, 0 ) AS PAY_BREACH ,
  COALESCE(TAKE_BREACH, 0 ) AS TAKE_BREACH ,
  COALESCE(COV_SURPLUS, 0 ) AS COV_SURPLUS ,
  COALESCE(MARK_SURPLUS, 0 ) AS MARK_SURPLUS ,
  COALESCE(FLOAT_SURPLUS, 0 ) AS FLOAT_SURPLUS ,
  COALESCE(LAST_LONG_FROZ, 0 ) AS LAST_LONG_FROZ ,
  COALESCE(DAY_LONG_FROZ, 0 ) AS DAY_LONG_FROZ ,
  COALESCE(LAST_FORWARD_FROZ, 0 ) AS LAST_FORWARD_FROZ ,
  COALESCE(DAY_FORWARD_FROZ, 0 ) AS DAY_FORWARD_FROZ ,
  COALESCE(INTE_INTEGRAL, 0 ) AS INTE_INTEGRAL ,
  COALESCE(PUNI_INTEGRAL, 0 ) AS PUNI_INTEGRAL ,
  COALESCE(WAIT_INCR_INTE, 0 ) AS WAIT_INCR_INTE ,
  COALESCE(WAIT_INCR_INTE_TAX, 0 ) AS WAIT_INCR_INTE_TAX ,
  COALESCE(DAY_INCR_INTE, 0 ) AS DAY_INCR_INTE ,
  COALESCE(DAY_INCR_INTE_TAX, 0 ) AS DAY_INCR_INTE_TAX ,
  COALESCE(LAST_TAKE_MARGIN, 0 ) AS LAST_TAKE_MARGIN ,
  COALESCE(DAY_TAKE_MARGIN, 0 ) AS DAY_TAKE_MARGIN ,
  COALESCE(LAST_STOR_FARE_FROZ, 0 ) AS LAST_STOR_FARE_FROZ ,
  COALESCE(DAY_STOR_FARE_FROZ, 0 ) AS DAY_STOR_FARE_FROZ ,
  DATE('${TX_DATE_YYYYMMDD}')                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               
FROM  dw_tdata.GTS_000_HIS_M_FUND_${TX_DATE_YYYYMMDD}                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       
;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      
COMMIT;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               

ENDOFINPUT

  close(VSQL);

  my $RET_CODE = $? >> 8;

  if ( $RET_CODE == 0 ) {
      return 0;
  }
  else {
      return 1;
  }
}

# ------------ main function ------------
sub main
{
   my $ret;
   open(LOGONFILE_H, "${LOGON_FILE}");
   ${LOGON_STR} = <LOGONFILE_H>;
   close(LOGONFILE_H);
   
   # Get the decoded logon string
   my($user,$passwd) = split(',',${LOGON_STR}); 
   #my $decodepasswd = `${AUTO_HOME}/bin/IceCode.exe -d "$passwd" "$user"`;                     
   #${LOGON_STR} = "|vsql -h 192.168.2.44 -p 5433 -d CPCIMDB -U ".$user." -w ".$decodepasswd;

   # Call vsql command to load data
   $ret = run_vsql_command();

   print "run_vsql_command() = $ret";
   return $ret;
}

# ------------ program section ------------
if ( $#ARGV < 0 ) {
   print "Usage: [perl ������ Control_File] (Control_File format: dir.jobnameYYYYMMDD or sysname_jobname_YYYYMMDD.dir) 
";
   print "
";
   exit(1);
}

# Get the first argument
${CONTROL_FILE} = $ARGV[0];

if (${CONTROL_FILE} =~/[0-9]{8}($|\.)/) {
   ${TX_DATE_YYYYMMDD} = substr($&,0,8);
}
else{
   print "Usage: [perl ������ Control_File] (Control_File format: dir.jobnameYYYYMMDD or sysname_jobname_YYYYMMDD.dir) 
";
   print "
";
   exit(1);
}

${TX_MON_DAY_MMDD} = substr(${TX_DATE_YYYYMMDD}, length(${TX_DATE_YYYYMMDD})-4,4);
${TX_DATE} = substr(${TX_DATE_YYYYMMDD}, 0, 4)."-".substr(${TX_DATE_YYYYMMDD}, 4, 2)."-".substr(${TX_DATE_YYYYMMDD}, 6, 2);
open(STDERR, ">&STDOUT");

my $ret = main();

exit($ret);
