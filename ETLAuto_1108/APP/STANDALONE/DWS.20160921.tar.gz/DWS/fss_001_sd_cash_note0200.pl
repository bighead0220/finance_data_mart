#!/usr/bin/perl

use strict;     # Declare using Perl strict syntax
use DBI;        # If you are using other package, declare here

# ------------ Variable Section ------------
my ${AUTO_HOME} = $ENV{"AUTO_HOME"};

my ${WML_DB} = $ENV{"AUTO_WML_DB"};
if ( !defined(${WML_DB}) ) {
    ${WML_DB} = "WML";
}
my ${WTL_DB} = $ENV{"AUTO_WTL_DB"};
if ( !defined(${WTL_DB}) ) {
    ${WTL_DB} = "WTL";
}
my ${WMLVIEW_DB} = $ENV{"AUTO_WMLVIEW_DB"};
if ( !defined(${WMLVIEW_DB}) ) {
    ${WMLVIEW_DB} = "WMLVIEW";
}
my ${WTLVIEW_DB} = $ENV{"AUTO_WTLVIEW_DB"};
if ( !defined(${WTLVIEW_DB}) ) {
    ${WTLVIEW_DB} = "WTLVIEW";
}

my ${NULL_DATE} = "1900-01-02";
my ${MIN_DATE} = "1900-01-01";
my ${MAX_DATE} = "2100-12-31";

my ${LOGON_FILE} = "${AUTO_HOME}/etc/VERTICA_LOGON";
my ${LOGON_STR};
my ${CONTROL_FILE};
my ${TX_DATE};
my ${TX_DATE_YYYYMMDD};
my ${TX_MON_DAY_MMDD};

# ------------ VSQL function ------------
sub run_vsql_command
{
  #my $rc = open(VSQL, "${LOGON_STR}");
  my $rc = open(VSQL, "|vsql -h 22.224.65.2 -p 5433 -d CPCIMDB -U dwpsbc -w dwpsbc2016");

  unless ($rc) {
      print "Could not invoke VSQL command
";
      return -1;
  }

# ------ Below are VSQL scripts ----------
  print VSQL <<ENDOFINPUT;

\\set ON_ERROR_STOP on

--Step0:
DELETE FROM dw_sdata.FSS_001_SD_CASH_NOTE WHERE start_dt>=DATE('${TX_DATE_YYYYMMDD}');
UPDATE dw_sdata.FSS_001_SD_CASH_NOTE SET end_dt=DATE('2100-12-31') WHERE end_dt>=DATE('${TX_DATE_YYYYMMDD}') AND end_dt<>DATE('2100-12-31');

--Step1:
CREATE LOCAL TEMPORARY TABLE  T_199 ON COMMIT PRESERVE ROWS AS SELECT * FROM dw_sdata.FSS_001_SD_CASH_NOTE WHERE 1=0;

--Step2:
INSERT  INTO T_199 (
  BATCHSERIAL,
  CUSTOMERID,
  SAVINGBONDACCT,
  ORGANCODE,
  OPERCODE,
  TRADEDATE,
  ACCTSERIAL,
  HOSTTIME,
  CUSTOMERNAME,
  CERTIFICATEKIND,
  CERTIFICATECODE,
  KINDCODE,
  GREENACCTNO,
  ACCTFLAG,
  TRADEFLAG,
  AMT,
  ENDDATE,
  YJINTEREST,
  BUSSTYPE,
  ZFNO,
  UNZFDATE,
  UNZFORGAN,
  UNZFTELLER,
  UNZFSERIAL,
  SENDFLAG,
  start_dt,
  end_dt)
SELECT
  N.BATCHSERIAL,
  N.CUSTOMERID,
  N.SAVINGBONDACCT,
  N.ORGANCODE,
  N.OPERCODE,
  N.TRADEDATE,
  N.ACCTSERIAL,
  N.HOSTTIME,
  N.CUSTOMERNAME,
  N.CERTIFICATEKIND,
  N.CERTIFICATECODE,
  N.KINDCODE,
  N.GREENACCTNO,
  N.ACCTFLAG,
  N.TRADEFLAG,
  N.AMT,
  N.ENDDATE,
  N.YJINTEREST,
  N.BUSSTYPE,
  N.ZFNO,
  N.UNZFDATE,
  N.UNZFORGAN,
  N.UNZFTELLER,
  N.UNZFSERIAL,
  N.SENDFLAG,
  DATE('${TX_DATE_YYYYMMDD}'),
  DATE('2100-12-31')
FROM 
 (SELECT
  COALESCE(BATCHSERIAL, '' ) AS BATCHSERIAL ,
  COALESCE(CUSTOMERID, '' ) AS CUSTOMERID ,
  COALESCE(SAVINGBONDACCT, '' ) AS SAVINGBONDACCT ,
  COALESCE(ORGANCODE, '' ) AS ORGANCODE ,
  COALESCE(OPERCODE, '' ) AS OPERCODE ,
  COALESCE(TRADEDATE, '' ) AS TRADEDATE ,
  COALESCE(ACCTSERIAL, 0 ) AS ACCTSERIAL ,
  COALESCE(HOSTTIME, '' ) AS HOSTTIME ,
  COALESCE(CUSTOMERNAME, '' ) AS CUSTOMERNAME ,
  COALESCE(CERTIFICATEKIND, '' ) AS CERTIFICATEKIND ,
  COALESCE(CERTIFICATECODE, '' ) AS CERTIFICATECODE ,
  COALESCE(KINDCODE, '' ) AS KINDCODE ,
  COALESCE(GREENACCTNO, '' ) AS GREENACCTNO ,
  COALESCE(ACCTFLAG, '' ) AS ACCTFLAG ,
  COALESCE(TRADEFLAG, '' ) AS TRADEFLAG ,
  COALESCE(AMT, 0 ) AS AMT ,
  COALESCE(ENDDATE, '' ) AS ENDDATE ,
  COALESCE(YJINTEREST, 0 ) AS YJINTEREST ,
  COALESCE(BUSSTYPE, '' ) AS BUSSTYPE ,
  COALESCE(ZFNO, '' ) AS ZFNO ,
  COALESCE(UNZFDATE, '' ) AS UNZFDATE ,
  COALESCE(UNZFORGAN, '' ) AS UNZFORGAN ,
  COALESCE(UNZFTELLER, '' ) AS UNZFTELLER ,
  COALESCE(UNZFSERIAL, '' ) AS UNZFSERIAL ,
  COALESCE(SENDFLAG, '' ) AS SENDFLAG 
 FROM  dw_tdata.FSS_001_SD_CASH_NOTE_${TX_DATE_YYYYMMDD}) N
LEFT JOIN
 (SELECT 
  BATCHSERIAL ,
  CUSTOMERID ,
  SAVINGBONDACCT ,
  ORGANCODE ,
  OPERCODE ,
  TRADEDATE ,
  ACCTSERIAL ,
  HOSTTIME ,
  CUSTOMERNAME ,
  CERTIFICATEKIND ,
  CERTIFICATECODE ,
  KINDCODE ,
  GREENACCTNO ,
  ACCTFLAG ,
  TRADEFLAG ,
  AMT ,
  ENDDATE ,
  YJINTEREST ,
  BUSSTYPE ,
  ZFNO ,
  UNZFDATE ,
  UNZFORGAN ,
  UNZFTELLER ,
  UNZFSERIAL ,
  SENDFLAG 
 FROM dw_sdata.FSS_001_SD_CASH_NOTE 
 WHERE END_DT = DATE('2100-12-31') ) T
ON N.BATCHSERIAL = T.BATCHSERIAL AND N.CUSTOMERID = T.CUSTOMERID AND N.SAVINGBONDACCT = T.SAVINGBONDACCT AND N.ORGANCODE = T.ORGANCODE AND N.OPERCODE = T.OPERCODE AND N.TRADEDATE = T.TRADEDATE AND N.ACCTSERIAL = T.ACCTSERIAL
WHERE
(T.BATCHSERIAL IS NULL AND T.CUSTOMERID IS NULL AND T.SAVINGBONDACCT IS NULL AND T.ORGANCODE IS NULL AND T.OPERCODE IS NULL AND T.TRADEDATE IS NULL AND T.ACCTSERIAL IS NULL)
 OR N.HOSTTIME<>T.HOSTTIME
 OR N.CUSTOMERNAME<>T.CUSTOMERNAME
 OR N.CERTIFICATEKIND<>T.CERTIFICATEKIND
 OR N.CERTIFICATECODE<>T.CERTIFICATECODE
 OR N.KINDCODE<>T.KINDCODE
 OR N.GREENACCTNO<>T.GREENACCTNO
 OR N.ACCTFLAG<>T.ACCTFLAG
 OR N.TRADEFLAG<>T.TRADEFLAG
 OR N.AMT<>T.AMT
 OR N.ENDDATE<>T.ENDDATE
 OR N.YJINTEREST<>T.YJINTEREST
 OR N.BUSSTYPE<>T.BUSSTYPE
 OR N.ZFNO<>T.ZFNO
 OR N.UNZFDATE<>T.UNZFDATE
 OR N.UNZFORGAN<>T.UNZFORGAN
 OR N.UNZFTELLER<>T.UNZFTELLER
 OR N.UNZFSERIAL<>T.UNZFSERIAL
 OR N.SENDFLAG<>T.SENDFLAG
;

--Step3:
UPDATE dw_sdata.FSS_001_SD_CASH_NOTE P 
SET End_Dt=DATE('${TX_DATE_YYYYMMDD}')
FROM T_199
WHERE P.End_Dt=DATE('2100-12-31')
AND P.BATCHSERIAL=T_199.BATCHSERIAL
AND P.CUSTOMERID=T_199.CUSTOMERID
AND P.SAVINGBONDACCT=T_199.SAVINGBONDACCT
AND P.ORGANCODE=T_199.ORGANCODE
AND P.OPERCODE=T_199.OPERCODE
AND P.TRADEDATE=T_199.TRADEDATE
AND P.ACCTSERIAL=T_199.ACCTSERIAL
;

--Step4:
INSERT  INTO dw_sdata.FSS_001_SD_CASH_NOTE SELECT * FROM T_199;

COMMIT;

ENDOFINPUT

  close(VSQL);

  my $RET_CODE = $? >> 8;

  if ( $RET_CODE == 0 ) {
      return 0;
  }
  else {
      return 1;
  }
}

# ------------ main function ------------
sub main
{
   my $ret;
   open(LOGONFILE_H, "${LOGON_FILE}");
   ${LOGON_STR} = <LOGONFILE_H>;
   close(LOGONFILE_H);
   
   # Get the decoded logon string
   my($user,$passwd) = split(',',${LOGON_STR}); 
   #my $decodepasswd = `${AUTO_HOME}/bin/IceCode.exe -d "$passwd" "$user"`;                     
   #${LOGON_STR} = "|vsql -h 192.168.2.44 -p 5433 -d CPCIMDB -U ".$user." -w ".$decodepasswd;

   # Call vsql command to load data
   $ret = run_vsql_command();

   print "run_vsql_command() = $ret";
   return $ret;
}

# ------------ program section ------------
if ( $#ARGV < 0 ) {
   print "Usage: [perl ������ Control_File] (Control_File format: dir.jobnameYYYYMMDD or sysname_jobname_YYYYMMDD.dir) 
";
   print "
";
   exit(1);
}

# Get the first argument
${CONTROL_FILE} = $ARGV[0];

if (${CONTROL_FILE} =~/[0-9]{8}($|\.)/) {
   ${TX_DATE_YYYYMMDD} = substr($&,0,8);
}
else{
   print "Usage: [perl ������ Control_File] (Control_File format: dir.jobnameYYYYMMDD or sysname_jobname_YYYYMMDD.dir) 
";
   print "
";
   exit(1);
}

${TX_MON_DAY_MMDD} = substr(${TX_DATE_YYYYMMDD}, length(${TX_DATE_YYYYMMDD})-4,4);
${TX_DATE} = substr(${TX_DATE_YYYYMMDD}, 0, 4)."-".substr(${TX_DATE_YYYYMMDD}, 4, 2)."-".substr(${TX_DATE_YYYYMMDD}, 6, 2);
open(STDERR, ">&STDOUT");

my $ret = main();

exit($ret);
