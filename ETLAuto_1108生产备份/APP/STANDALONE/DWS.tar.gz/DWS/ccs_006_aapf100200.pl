#!/usr/bin/perl

use strict;     # Declare using Perl strict syntax
use DBI;        # If you are using other package, declare here

# ------------ Variable Section ------------
my ${AUTO_HOME} = $ENV{"AUTO_HOME"};

my ${WML_DB} = $ENV{"AUTO_WML_DB"};
if ( !defined(${WML_DB}) ) {
    ${WML_DB} = "WML";
}
my ${WTL_DB} = $ENV{"AUTO_WTL_DB"};
if ( !defined(${WTL_DB}) ) {
    ${WTL_DB} = "WTL";
}
my ${WMLVIEW_DB} = $ENV{"AUTO_WMLVIEW_DB"};
if ( !defined(${WMLVIEW_DB}) ) {
    ${WMLVIEW_DB} = "WMLVIEW";
}
my ${WTLVIEW_DB} = $ENV{"AUTO_WTLVIEW_DB"};
if ( !defined(${WTLVIEW_DB}) ) {
    ${WTLVIEW_DB} = "WTLVIEW";
}

my ${NULL_DATE} = "1900-01-02";
my ${MIN_DATE} = "1900-01-01";
my ${MAX_DATE} = "2100-12-31";

my ${LOGON_FILE} = "${AUTO_HOME}/etc/VERTICA_LOGON";
my ${LOGON_STR};
my ${CONTROL_FILE};
my ${TX_DATE};
my ${TX_DATE_YYYYMMDD};
my ${TX_MON_DAY_MMDD};

# ------------ VSQL function ------------
sub run_vsql_command
{
  #my $rc = open(VSQL, "${LOGON_STR}");
  my $rc = open(VSQL, "|vsql -h 22.224.65.2 -p 5433 -d CPCIMDB -U dwpsbc -w dwpsbc2016");

  unless ($rc) {
      print "Could not invoke VSQL command
";
      return -1;
  }

# ------ Below are VSQL scripts ----------
  print VSQL <<ENDOFINPUT;

\\set ON_ERROR_STOP on

--Step0:
DELETE FROM dw_sdata.CCS_006_AAPF10 WHERE start_dt>=DATE('${TX_DATE_YYYYMMDD}');
UPDATE dw_sdata.CCS_006_AAPF10 SET end_dt=DATE('2100-12-31') WHERE end_dt>=DATE('${TX_DATE_YYYYMMDD}') AND end_dt<>DATE('2100-12-31');

--Step1:
CREATE LOCAL TEMPORARY TABLE  T_126 ON COMMIT PRESERVE ROWS AS SELECT * FROM dw_sdata.CCS_006_AAPF10 WHERE 1=0;

--Step2:
INSERT  INTO T_126 (
  AA10PRE,
  AA10DPNOK,
  AA10DPNOA,
  AA10DUEBNO,
  AA10ACID,
  AA10TYPE,
  AA10LNCLS,
  AA10NAME,
  AA10CUR,
  AA10NOTEXC,
  AA10SUBJ,
  AA10ACTYP,
  AA10STAT,
  AA10BALD,
  AA10BAL,
  AA10BALY,
  AA10AMR,
  AA10AMRX,
  AA10AMRY,
  AA10YTBAL,
  AA10CODE,
  AA10DATEC,
  AA10DATED,
  AA10DATEA,
  AA10CTLS,
  AA10ACCOD,
  AA10DAC,
  AA10NUM1,
  AA10NUM2,
  AA10HOLD1,
  AA10HOLD2,
  AA10OPT3,
  AA10BL1,
  AA10DATE1,
  start_dt,
  end_dt)
SELECT
  N.AA10PRE,
  N.AA10DPNOK,
  N.AA10DPNOA,
  N.AA10DUEBNO,
  N.AA10ACID,
  N.AA10TYPE,
  N.AA10LNCLS,
  N.AA10NAME,
  N.AA10CUR,
  N.AA10NOTEXC,
  N.AA10SUBJ,
  N.AA10ACTYP,
  N.AA10STAT,
  N.AA10BALD,
  N.AA10BAL,
  N.AA10BALY,
  N.AA10AMR,
  N.AA10AMRX,
  N.AA10AMRY,
  N.AA10YTBAL,
  N.AA10CODE,
  N.AA10DATEC,
  N.AA10DATED,
  N.AA10DATEA,
  N.AA10CTLS,
  N.AA10ACCOD,
  N.AA10DAC,
  N.AA10NUM1,
  N.AA10NUM2,
  N.AA10HOLD1,
  N.AA10HOLD2,
  N.AA10OPT3,
  N.AA10BL1,
  N.AA10DATE1,
  DATE('${TX_DATE_YYYYMMDD}'),
  DATE('2100-12-31')
FROM 
 (SELECT
  COALESCE(AA10PRE, '' ) AS AA10PRE ,
  COALESCE(AA10DPNOK, '' ) AS AA10DPNOK ,
  COALESCE(AA10DPNOA, '' ) AS AA10DPNOA ,
  COALESCE(AA10DUEBNO, '' ) AS AA10DUEBNO ,
  COALESCE(AA10ACID, 0 ) AS AA10ACID ,
  COALESCE(AA10TYPE, '' ) AS AA10TYPE ,
  COALESCE(AA10LNCLS, '' ) AS AA10LNCLS ,
  COALESCE(AA10NAME, '' ) AS AA10NAME ,
  COALESCE(AA10CUR, '' ) AS AA10CUR ,
  COALESCE(AA10NOTEXC, '' ) AS AA10NOTEXC ,
  COALESCE(AA10SUBJ, '' ) AS AA10SUBJ ,
  COALESCE(AA10ACTYP, '' ) AS AA10ACTYP ,
  COALESCE(AA10STAT, '' ) AS AA10STAT ,
  COALESCE(AA10BALD, '' ) AS AA10BALD ,
  COALESCE(AA10BAL, 0 ) AS AA10BAL ,
  COALESCE(AA10BALY, 0 ) AS AA10BALY ,
  COALESCE(AA10AMR, 0 ) AS AA10AMR ,
  COALESCE(AA10AMRX, 0 ) AS AA10AMRX ,
  COALESCE(AA10AMRY, 0 ) AS AA10AMRY ,
  COALESCE(AA10YTBAL, 0 ) AS AA10YTBAL ,
  COALESCE(AA10CODE, '' ) AS AA10CODE ,
  COALESCE(AA10DATEC, '' ) AS AA10DATEC ,
  COALESCE(AA10DATED, '' ) AS AA10DATED ,
  COALESCE(AA10DATEA, '' ) AS AA10DATEA ,
  COALESCE(AA10CTLS, '' ) AS AA10CTLS ,
  COALESCE(AA10ACCOD, '' ) AS AA10ACCOD ,
  COALESCE(AA10DAC, '' ) AS AA10DAC ,
  COALESCE(AA10NUM1, 0 ) AS AA10NUM1 ,
  COALESCE(AA10NUM2, 0 ) AS AA10NUM2 ,
  COALESCE(AA10HOLD1, 0 ) AS AA10HOLD1 ,
  COALESCE(AA10HOLD2, 0 ) AS AA10HOLD2 ,
  COALESCE(AA10OPT3, '' ) AS AA10OPT3 ,
  COALESCE(AA10BL1, '' ) AS AA10BL1 ,
  COALESCE(AA10DATE1, '' ) AS AA10DATE1 
 FROM  dw_tdata.CCS_006_AAPF10_${TX_DATE_YYYYMMDD}) N
LEFT JOIN
 (SELECT 
  AA10PRE ,
  AA10DPNOK ,
  AA10DPNOA ,
  AA10DUEBNO ,
  AA10ACID ,
  AA10TYPE ,
  AA10LNCLS ,
  AA10NAME ,
  AA10CUR ,
  AA10NOTEXC ,
  AA10SUBJ ,
  AA10ACTYP ,
  AA10STAT ,
  AA10BALD ,
  AA10BAL ,
  AA10BALY ,
  AA10AMR ,
  AA10AMRX ,
  AA10AMRY ,
  AA10YTBAL ,
  AA10CODE ,
  AA10DATEC ,
  AA10DATED ,
  AA10DATEA ,
  AA10CTLS ,
  AA10ACCOD ,
  AA10DAC ,
  AA10NUM1 ,
  AA10NUM2 ,
  AA10HOLD1 ,
  AA10HOLD2 ,
  AA10OPT3 ,
  AA10BL1 ,
  AA10DATE1 
 FROM dw_sdata.CCS_006_AAPF10 
 WHERE END_DT = DATE('2100-12-31') ) T
ON N.AA10DPNOA = T.AA10DPNOA AND N.AA10DUEBNO = T.AA10DUEBNO AND N.AA10ACID = T.AA10ACID
WHERE
(T.AA10DPNOA IS NULL AND T.AA10DUEBNO IS NULL AND T.AA10ACID IS NULL)
 OR N.AA10PRE<>T.AA10PRE
 OR N.AA10DPNOK<>T.AA10DPNOK
 OR N.AA10TYPE<>T.AA10TYPE
 OR N.AA10LNCLS<>T.AA10LNCLS
 OR N.AA10NAME<>T.AA10NAME
 OR N.AA10CUR<>T.AA10CUR
 OR N.AA10NOTEXC<>T.AA10NOTEXC
 OR N.AA10SUBJ<>T.AA10SUBJ
 OR N.AA10ACTYP<>T.AA10ACTYP
 OR N.AA10STAT<>T.AA10STAT
 OR N.AA10BALD<>T.AA10BALD
 OR N.AA10BAL<>T.AA10BAL
 OR N.AA10BALY<>T.AA10BALY
 OR N.AA10AMR<>T.AA10AMR
 OR N.AA10AMRX<>T.AA10AMRX
 OR N.AA10AMRY<>T.AA10AMRY
 OR N.AA10YTBAL<>T.AA10YTBAL
 OR N.AA10CODE<>T.AA10CODE
 OR N.AA10DATEC<>T.AA10DATEC
 OR N.AA10DATED<>T.AA10DATED
 OR N.AA10DATEA<>T.AA10DATEA
 OR N.AA10CTLS<>T.AA10CTLS
 OR N.AA10ACCOD<>T.AA10ACCOD
 OR N.AA10DAC<>T.AA10DAC
 OR N.AA10NUM1<>T.AA10NUM1
 OR N.AA10NUM2<>T.AA10NUM2
 OR N.AA10HOLD1<>T.AA10HOLD1
 OR N.AA10HOLD2<>T.AA10HOLD2
 OR N.AA10OPT3<>T.AA10OPT3
 OR N.AA10BL1<>T.AA10BL1
 OR N.AA10DATE1<>T.AA10DATE1
;

--Step3:
UPDATE dw_sdata.CCS_006_AAPF10 P 
SET End_Dt=DATE('${TX_DATE_YYYYMMDD}')
FROM T_126
WHERE P.End_Dt=DATE('2100-12-31')
AND P.AA10DPNOA=T_126.AA10DPNOA
AND P.AA10DUEBNO=T_126.AA10DUEBNO
AND P.AA10ACID=T_126.AA10ACID
;

--Step4:
INSERT  INTO dw_sdata.CCS_006_AAPF10 SELECT * FROM T_126;

COMMIT;

ENDOFINPUT

  close(VSQL);

  my $RET_CODE = $? >> 8;

  if ( $RET_CODE == 0 ) {
      return 0;
  }
  else {
      return 1;
  }
}

# ------------ main function ------------
sub main
{
   my $ret;
   open(LOGONFILE_H, "${LOGON_FILE}");
   ${LOGON_STR} = <LOGONFILE_H>;
   close(LOGONFILE_H);
   
   # Get the decoded logon string
   my($user,$passwd) = split(',',${LOGON_STR}); 
   #my $decodepasswd = `${AUTO_HOME}/bin/IceCode.exe -d "$passwd" "$user"`;                     
   #${LOGON_STR} = "|vsql -h 192.168.2.44 -p 5433 -d CPCIMDB -U ".$user." -w ".$decodepasswd;

   # Call vsql command to load data
   $ret = run_vsql_command();

   print "run_vsql_command() = $ret";
   return $ret;
}

# ------------ program section ------------
if ( $#ARGV < 0 ) {
   print "Usage: [perl ������ Control_File] (Control_File format: dir.jobnameYYYYMMDD or sysname_jobname_YYYYMMDD.dir) 
";
   print "
";
   exit(1);
}

# Get the first argument
${CONTROL_FILE} = $ARGV[0];

if (${CONTROL_FILE} =~/[0-9]{8}($|\.)/) {
   ${TX_DATE_YYYYMMDD} = substr($&,0,8);
}
else{
   print "Usage: [perl ������ Control_File] (Control_File format: dir.jobnameYYYYMMDD or sysname_jobname_YYYYMMDD.dir) 
";
   print "
";
   exit(1);
}

${TX_MON_DAY_MMDD} = substr(${TX_DATE_YYYYMMDD}, length(${TX_DATE_YYYYMMDD})-4,4);
${TX_DATE} = substr(${TX_DATE_YYYYMMDD}, 0, 4)."-".substr(${TX_DATE_YYYYMMDD}, 4, 2)."-".substr(${TX_DATE_YYYYMMDD}, 6, 2);
open(STDERR, ">&STDOUT");

my $ret = main();

exit($ret);
