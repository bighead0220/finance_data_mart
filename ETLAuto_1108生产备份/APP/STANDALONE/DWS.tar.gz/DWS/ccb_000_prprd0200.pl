#!/usr/bin/perl

use strict;     # Declare using Perl strict syntax
use DBI;        # If you are using other package, declare here

# ------------ Variable Section ------------
my ${AUTO_HOME} = $ENV{"AUTO_HOME"};

my ${WML_DB} = $ENV{"AUTO_WML_DB"};
if ( !defined(${WML_DB}) ) {
    ${WML_DB} = "WML";
}
my ${WTL_DB} = $ENV{"AUTO_WTL_DB"};
if ( !defined(${WTL_DB}) ) {
    ${WTL_DB} = "WTL";
}
my ${WMLVIEW_DB} = $ENV{"AUTO_WMLVIEW_DB"};
if ( !defined(${WMLVIEW_DB}) ) {
    ${WMLVIEW_DB} = "WMLVIEW";
}
my ${WTLVIEW_DB} = $ENV{"AUTO_WTLVIEW_DB"};
if ( !defined(${WTLVIEW_DB}) ) {
    ${WTLVIEW_DB} = "WTLVIEW";
}

my ${NULL_DATE} = "1900-01-02";
my ${MIN_DATE} = "1900-01-01";
my ${MAX_DATE} = "2100-12-31";

my ${LOGON_FILE} = "${AUTO_HOME}/etc/VERTICA_LOGON";
my ${LOGON_STR};
my ${CONTROL_FILE};
my ${TX_DATE};
my ${TX_DATE_YYYYMMDD};
my ${TX_MON_DAY_MMDD};

# ------------ VSQL function ------------
sub run_vsql_command
{
  #my $rc = open(VSQL, "${LOGON_STR}");
  my $rc = open(VSQL, "|vsql -h 22.224.65.2 -p 5433 -d CPCIMDB -U dwpsbc -w dwpsbc2016");

  unless ($rc) {
      print "Could not invoke VSQL command
";
      return -1;
  }

# ------ Below are VSQL scripts ----------
  print VSQL <<ENDOFINPUT;

\\set ON_ERROR_STOP on

--Step0:
DELETE FROM dw_sdata.CCB_000_PRPRD WHERE start_dt>=DATE('${TX_DATE_YYYYMMDD}');
UPDATE dw_sdata.CCB_000_PRPRD SET end_dt=DATE('2100-12-31') WHERE end_dt>=DATE('${TX_DATE_YYYYMMDD}') AND end_dt<>DATE('2100-12-31');

--Step1:
CREATE LOCAL TEMPORARY TABLE  T_102 ON COMMIT PRESERVE ROWS AS SELECT * FROM dw_sdata.CCB_000_PRPRD WHERE 1=0;

--Step2:
INSERT  INTO T_102 (
  BANK,
  MERCHANT,
  PROD_ID,
  CLOSEDATE,
  FEE_AMT,
  FEE_AMT_SIGN,
  FEE_PCNT,
  INT_RATE,
  MP_MAX_AMT,
  NBR_MTHS,
  OPENDATE,
  ORIG_BAL,
  PRIME_RATE,
  PROD_DESC,
  XSTATUS,
  AUTH_FLAG,
  COMM_AMT,
  COMM_PCNT,
  FEE_FLAG,
  MAX_COMM,
  MIN_COMM,
  AUTO_AUTH,
  MP_MIN_AMT,
  ACCE_FEE,
  ACCE_MAXFE,
  ACCE_MINFE,
  ACCE_PCNT,
  REVS_FEE,
  REVS_MAXFE,
  REVS_MINFE,
  REVS_PCNT,
  MP_L_FLAG,
  DELAY_MTH,
  DELAY_FEE,
  DELAY_PCNT,
  DELAY_MINFE,
  DELAY_MAXFE,
  PAUSE_NBRS,
  PAUSE_FEE,
  PAUSE_PCNT,
  PAUSE_MINFE,
  PAUSE_MAXFE,
  INTER_MTHS,
  NBR_BLOCD,
  INSTL_PCNT,
  REMPPL_YN,
  INSTL_FLAG,
  FREEFEE,
  start_dt,
  end_dt)
SELECT
  N.BANK,
  N.MERCHANT,
  N.PROD_ID,
  N.CLOSEDATE,
  N.FEE_AMT,
  N.FEE_AMT_SIGN,
  N.FEE_PCNT,
  N.INT_RATE,
  N.MP_MAX_AMT,
  N.NBR_MTHS,
  N.OPENDATE,
  N.ORIG_BAL,
  N.PRIME_RATE,
  N.PROD_DESC,
  N.XSTATUS,
  N.AUTH_FLAG,
  N.COMM_AMT,
  N.COMM_PCNT,
  N.FEE_FLAG,
  N.MAX_COMM,
  N.MIN_COMM,
  N.AUTO_AUTH,
  N.MP_MIN_AMT,
  N.ACCE_FEE,
  N.ACCE_MAXFE,
  N.ACCE_MINFE,
  N.ACCE_PCNT,
  N.REVS_FEE,
  N.REVS_MAXFE,
  N.REVS_MINFE,
  N.REVS_PCNT,
  N.MP_L_FLAG,
  N.DELAY_MTH,
  N.DELAY_FEE,
  N.DELAY_PCNT,
  N.DELAY_MINFE,
  N.DELAY_MAXFE,
  N.PAUSE_NBRS,
  N.PAUSE_FEE,
  N.PAUSE_PCNT,
  N.PAUSE_MINFE,
  N.PAUSE_MAXFE,
  N.INTER_MTHS,
  N.NBR_BLOCD,
  N.INSTL_PCNT,
  N.REMPPL_YN,
  N.INSTL_FLAG,
  N.FREEFEE,
  DATE('${TX_DATE_YYYYMMDD}'),
  DATE('2100-12-31')
FROM 
 (SELECT
  COALESCE(BANK, 0 ) AS BANK ,
  COALESCE(MERCHANT, '' ) AS MERCHANT ,
  COALESCE(PROD_ID, '' ) AS PROD_ID ,
  COALESCE(CLOSEDATE, 0 ) AS CLOSEDATE ,
  COALESCE(FEE_AMT, 0 ) AS FEE_AMT ,
  COALESCE(FEE_AMT_SIGN, '' ) AS FEE_AMT_SIGN ,
  COALESCE(FEE_PCNT, 0 ) AS FEE_PCNT ,
  COALESCE(INT_RATE, 0 ) AS INT_RATE ,
  COALESCE(MP_MAX_AMT, 0 ) AS MP_MAX_AMT ,
  COALESCE(NBR_MTHS, 0 ) AS NBR_MTHS ,
  COALESCE(OPENDATE, 0 ) AS OPENDATE ,
  COALESCE(ORIG_BAL, 0 ) AS ORIG_BAL ,
  COALESCE(PRIME_RATE, 0 ) AS PRIME_RATE ,
  COALESCE(PROD_DESC, '' ) AS PROD_DESC ,
  COALESCE(XSTATUS, '' ) AS XSTATUS ,
  COALESCE(AUTH_FLAG, 0 ) AS AUTH_FLAG ,
  COALESCE(COMM_AMT, 0 ) AS COMM_AMT ,
  COALESCE(COMM_PCNT, 0 ) AS COMM_PCNT ,
  COALESCE(FEE_FLAG, 0 ) AS FEE_FLAG ,
  COALESCE(MAX_COMM, 0 ) AS MAX_COMM ,
  COALESCE(MIN_COMM, 0 ) AS MIN_COMM ,
  COALESCE(AUTO_AUTH, 0 ) AS AUTO_AUTH ,
  COALESCE(MP_MIN_AMT, 0 ) AS MP_MIN_AMT ,
  COALESCE(ACCE_FEE, 0 ) AS ACCE_FEE ,
  COALESCE(ACCE_MAXFE, 0 ) AS ACCE_MAXFE ,
  COALESCE(ACCE_MINFE, 0 ) AS ACCE_MINFE ,
  COALESCE(ACCE_PCNT, 0 ) AS ACCE_PCNT ,
  COALESCE(REVS_FEE, 0 ) AS REVS_FEE ,
  COALESCE(REVS_MAXFE, 0 ) AS REVS_MAXFE ,
  COALESCE(REVS_MINFE, 0 ) AS REVS_MINFE ,
  COALESCE(REVS_PCNT, 0 ) AS REVS_PCNT ,
  COALESCE(MP_L_FLAG, 0 ) AS MP_L_FLAG ,
  COALESCE(DELAY_MTH, 0 ) AS DELAY_MTH ,
  COALESCE(DELAY_FEE, 0 ) AS DELAY_FEE ,
  COALESCE(DELAY_PCNT, 0 ) AS DELAY_PCNT ,
  COALESCE(DELAY_MINFE, 0 ) AS DELAY_MINFE ,
  COALESCE(DELAY_MAXFE, 0 ) AS DELAY_MAXFE ,
  COALESCE(PAUSE_NBRS, 0 ) AS PAUSE_NBRS ,
  COALESCE(PAUSE_FEE, 0 ) AS PAUSE_FEE ,
  COALESCE(PAUSE_PCNT, 0 ) AS PAUSE_PCNT ,
  COALESCE(PAUSE_MINFE, 0 ) AS PAUSE_MINFE ,
  COALESCE(PAUSE_MAXFE, 0 ) AS PAUSE_MAXFE ,
  COALESCE(INTER_MTHS, 0 ) AS INTER_MTHS ,
  COALESCE(NBR_BLOCD, 0 ) AS NBR_BLOCD ,
  COALESCE(INSTL_PCNT, 0 ) AS INSTL_PCNT ,
  COALESCE(REMPPL_YN, 0 ) AS REMPPL_YN ,
  COALESCE(INSTL_FLAG, 0 ) AS INSTL_FLAG ,
  COALESCE(FREEFEE,0) AS FREEFEE
 FROM  dw_tdata.CCB_000_PRPRD_${TX_DATE_YYYYMMDD}) N
LEFT JOIN
 (SELECT 
  BANK ,
  MERCHANT ,
  PROD_ID ,
  CLOSEDATE ,
  FEE_AMT ,
  FEE_AMT_SIGN ,
  FEE_PCNT ,
  INT_RATE ,
  MP_MAX_AMT ,
  NBR_MTHS ,
  OPENDATE ,
  ORIG_BAL ,
  PRIME_RATE ,
  PROD_DESC ,
  XSTATUS ,
  AUTH_FLAG ,
  COMM_AMT ,
  COMM_PCNT ,
  FEE_FLAG ,
  MAX_COMM ,
  MIN_COMM ,
  AUTO_AUTH ,
  MP_MIN_AMT ,
  ACCE_FEE ,
  ACCE_MAXFE ,
  ACCE_MINFE ,
  ACCE_PCNT ,
  REVS_FEE ,
  REVS_MAXFE ,
  REVS_MINFE ,
  REVS_PCNT ,
  MP_L_FLAG ,
  DELAY_MTH ,
  DELAY_FEE ,
  DELAY_PCNT ,
  DELAY_MINFE ,
  DELAY_MAXFE ,
  PAUSE_NBRS ,
  PAUSE_FEE ,
  PAUSE_PCNT ,
  PAUSE_MINFE ,
  PAUSE_MAXFE ,
  INTER_MTHS ,
  NBR_BLOCD ,
  INSTL_PCNT ,
  REMPPL_YN ,
  INSTL_FLAG ,
  FREEFEE
 FROM dw_sdata.CCB_000_PRPRD 
 WHERE END_DT = DATE('2100-12-31') ) T
ON N.PROD_ID = T.PROD_ID
WHERE
(T.PROD_ID IS NULL)
 OR N.BANK<>T.BANK
 OR N.MERCHANT<>T.MERCHANT
 OR N.CLOSEDATE<>T.CLOSEDATE
 OR N.FEE_AMT<>T.FEE_AMT
 OR N.FEE_AMT_SIGN<>T.FEE_AMT_SIGN
 OR N.FEE_PCNT<>T.FEE_PCNT
 OR N.INT_RATE<>T.INT_RATE
 OR N.MP_MAX_AMT<>T.MP_MAX_AMT
 OR N.NBR_MTHS<>T.NBR_MTHS
 OR N.OPENDATE<>T.OPENDATE
 OR N.ORIG_BAL<>T.ORIG_BAL
 OR N.PRIME_RATE<>T.PRIME_RATE
 OR N.PROD_DESC<>T.PROD_DESC
 OR N.XSTATUS<>T.XSTATUS
 OR N.AUTH_FLAG<>T.AUTH_FLAG
 OR N.COMM_AMT<>T.COMM_AMT
 OR N.COMM_PCNT<>T.COMM_PCNT
 OR N.FEE_FLAG<>T.FEE_FLAG
 OR N.MAX_COMM<>T.MAX_COMM
 OR N.MIN_COMM<>T.MIN_COMM
 OR N.AUTO_AUTH<>T.AUTO_AUTH
 OR N.MP_MIN_AMT<>T.MP_MIN_AMT
 OR N.ACCE_FEE<>T.ACCE_FEE
 OR N.ACCE_MAXFE<>T.ACCE_MAXFE
 OR N.ACCE_MINFE<>T.ACCE_MINFE
 OR N.ACCE_PCNT<>T.ACCE_PCNT
 OR N.REVS_FEE<>T.REVS_FEE
 OR N.REVS_MAXFE<>T.REVS_MAXFE
 OR N.REVS_MINFE<>T.REVS_MINFE
 OR N.REVS_PCNT<>T.REVS_PCNT
 OR N.MP_L_FLAG<>T.MP_L_FLAG
 OR N.DELAY_MTH<>T.DELAY_MTH
 OR N.DELAY_FEE<>T.DELAY_FEE
 OR N.DELAY_PCNT<>T.DELAY_PCNT
 OR N.DELAY_MINFE<>T.DELAY_MINFE
 OR N.DELAY_MAXFE<>T.DELAY_MAXFE
 OR N.PAUSE_NBRS<>T.PAUSE_NBRS
 OR N.PAUSE_FEE<>T.PAUSE_FEE
 OR N.PAUSE_PCNT<>T.PAUSE_PCNT
 OR N.PAUSE_MINFE<>T.PAUSE_MINFE
 OR N.PAUSE_MAXFE<>T.PAUSE_MAXFE
 OR N.INTER_MTHS<>T.INTER_MTHS
 OR N.NBR_BLOCD<>T.NBR_BLOCD
 OR N.INSTL_PCNT<>T.INSTL_PCNT
 OR N.REMPPL_YN<>T.REMPPL_YN
 OR N.INSTL_FLAG<>T.INSTL_FLAG
 OR N.FREEFEE<>T.FREEFEE
;

--Step3:
UPDATE dw_sdata.CCB_000_PRPRD P 
SET End_Dt=DATE('${TX_DATE_YYYYMMDD}')
FROM T_102
WHERE P.End_Dt=DATE('2100-12-31')
AND P.PROD_ID=T_102.PROD_ID
;

--Step4:
INSERT  INTO dw_sdata.CCB_000_PRPRD SELECT * FROM T_102;

COMMIT;

ENDOFINPUT

  close(VSQL);

  my $RET_CODE = $? >> 8;

  if ( $RET_CODE == 0 ) {
      return 0;
  }
  else {
      return 1;
  }
}

# ------------ main function ------------
sub main
{
   my $ret;
   open(LOGONFILE_H, "${LOGON_FILE}");
   ${LOGON_STR} = <LOGONFILE_H>;
   close(LOGONFILE_H);
   
   # Get the decoded logon string
   my($user,$passwd) = split(',',${LOGON_STR}); 
   #my $decodepasswd = `${AUTO_HOME}/bin/IceCode.exe -d "$passwd" "$user"`;                     
   #${LOGON_STR} = "|vsql -h 192.168.2.44 -p 5433 -d CPCIMDB -U ".$user." -w ".$decodepasswd;

   # Call vsql command to load data
   $ret = run_vsql_command();

   print "run_vsql_command() = $ret";
   return $ret;
}

# ------------ program section ------------
if ( $#ARGV < 0 ) {
   print "Usage: [perl ������ Control_File] (Control_File format: dir.jobnameYYYYMMDD or sysname_jobname_YYYYMMDD.dir) 
";
   print "
";
   exit(1);
}

# Get the first argument
${CONTROL_FILE} = $ARGV[0];

if (${CONTROL_FILE} =~/[0-9]{8}($|\.)/) {
   ${TX_DATE_YYYYMMDD} = substr($&,0,8);
}
else{
   print "Usage: [perl ������ Control_File] (Control_File format: dir.jobnameYYYYMMDD or sysname_jobname_YYYYMMDD.dir) 
";
   print "
";
   exit(1);
}

${TX_MON_DAY_MMDD} = substr(${TX_DATE_YYYYMMDD}, length(${TX_DATE_YYYYMMDD})-4,4);
${TX_DATE} = substr(${TX_DATE_YYYYMMDD}, 0, 4)."-".substr(${TX_DATE_YYYYMMDD}, 4, 2)."-".substr(${TX_DATE_YYYYMMDD}, 6, 2);
open(STDERR, ">&STDOUT");

my $ret = main();

exit($ret);
