#!/usr/bin/perl

use strict;     # Declare using Perl strict syntax
use DBI;        # If you are using other package, declare here

# ------------ Variable Section ------------
my ${AUTO_HOME} = $ENV{"AUTO_HOME"};

my ${WML_DB} = $ENV{"AUTO_WML_DB"};
if ( !defined(${WML_DB}) ) {
    ${WML_DB} = "WML";
}
my ${WTL_DB} = $ENV{"AUTO_WTL_DB"};
if ( !defined(${WTL_DB}) ) {
    ${WTL_DB} = "WTL";
}
my ${WMLVIEW_DB} = $ENV{"AUTO_WMLVIEW_DB"};
if ( !defined(${WMLVIEW_DB}) ) {
    ${WMLVIEW_DB} = "WMLVIEW";
}
my ${WTLVIEW_DB} = $ENV{"AUTO_WTLVIEW_DB"};
if ( !defined(${WTLVIEW_DB}) ) {
    ${WTLVIEW_DB} = "WTLVIEW";
}

my ${NULL_DATE} = "1900-01-02";
my ${MIN_DATE} = "1900-01-01";
my ${MAX_DATE} = "2100-12-31";

my ${LOGON_FILE} = "${AUTO_HOME}/etc/VERTICA_LOGON";
my ${LOGON_STR};
my ${CONTROL_FILE};
my ${TX_DATE};
my ${TX_DATE_YYYYMMDD};
my ${TX_MON_DAY_MMDD};

# ------------ VSQL function ------------
sub run_vsql_command
{
  #my $rc = open(VSQL, "${LOGON_STR}");
  my $rc = open(VSQL, "|vsql -h 22.224.65.2 -p 5433 -d CPCIMDB -U dwpsbc -w dwpsbc2016");

  unless ($rc) {
      print "Could not invoke VSQL command
";
      return -1;
  }

# ------ Below are VSQL scripts ----------
  print VSQL <<ENDOFINPUT;

\\set ON_ERROR_STOP on

--Step0:
DELETE FROM dw_sdata.CCB_000_PRMAU WHERE start_dt>=DATE('${TX_DATE_YYYYMMDD}');
UPDATE dw_sdata.CCB_000_PRMAU SET end_dt=DATE('2100-12-31') WHERE end_dt>=DATE('${TX_DATE_YYYYMMDD}') AND end_dt<>DATE('2100-12-31');

--Step1:
CREATE LOCAL TEMPORARY TABLE  T_98 ON COMMIT PRESERVE ROWS AS SELECT * FROM dw_sdata.CCB_000_PRMAU WHERE 1=0;

--Step2:
INSERT  INTO T_98 (
  BANK,
  PRODUCT,
  AU_LMTPRCT,
  AUTH_OVER,
  AUTH_OVERX,
  CA_LMTPRCT,
  CASH_OVER,
  CASH_OVERX,
  COLIM_MSG,
  COLIM_RESP,
  DAY_N_ACTI,
  DAY2_N_ACT,
  DAY3_N_ACT,
  EX_AMT_FLG,
  EX_AMT_LOW,
  EX_PER_DAY,
  EX_PER_MTH,
  FST_CA_MG,
  FST_CA_RP,
  FST_CACRL,
  FST_CACRP,
  FST_PUR_MG,
  FST_PUR_RP,
  FST_PURCRL,
  FST_PURCRP,
  MARKUP_PCT,
  NO_OLINT,
  OLIM_MSG,
  OLIM_RESP,
  SMS_LOWAMT,
  SMS_LOWAMX,
  MAX_CASH,
  EC_YN,
  EC_RESP,
  EC_MSG,
  CC_YN,
  CC_RSP,
  CC_MSG,
  ECAMT,
  ECAMT_RSP,
  ECAMT_MSG,
  CCAMT,
  CCAMT_RSP,
  CCAMT_MSG,
  OL_PRCT,
  DAY4_U_USE,
  MSG_PURCRP,
  YAMT_MIN,
  WP_YN,
  start_dt,
  end_dt)
SELECT
  N.BANK,
  N.PRODUCT,
  N.AU_LMTPRCT,
  N.AUTH_OVER,
  N.AUTH_OVERX,
  N.CA_LMTPRCT,
  N.CASH_OVER,
  N.CASH_OVERX,
  N.COLIM_MSG,
  N.COLIM_RESP,
  N.DAY_N_ACTI,
  N.DAY2_N_ACT,
  N.DAY3_N_ACT,
  N.EX_AMT_FLG,
  N.EX_AMT_LOW,
  N.EX_PER_DAY,
  N.EX_PER_MTH,
  N.FST_CA_MG,
  N.FST_CA_RP,
  N.FST_CACRL,
  N.FST_CACRP,
  N.FST_PUR_MG,
  N.FST_PUR_RP,
  N.FST_PURCRL,
  N.FST_PURCRP,
  N.MARKUP_PCT,
  N.NO_OLINT,
  N.OLIM_MSG,
  N.OLIM_RESP,
  N.SMS_LOWAMT,
  N.SMS_LOWAMX,
  N.MAX_CASH,
  N.EC_YN,
  N.EC_RESP,
  N.EC_MSG,
  N.CC_YN,
  N.CC_RSP,
  N.CC_MSG,
  N.ECAMT,
  N.ECAMT_RSP,
  N.ECAMT_MSG,
  N.CCAMT,
  N.CCAMT_RSP,
  N.CCAMT_MSG,
  N.OL_PRCT,
  N.DAY4_U_USE,
  N.MSG_PURCRP,
  N.YAMT_MIN,
  N.WP_YN,
  DATE('${TX_DATE_YYYYMMDD}'),
  DATE('2100-12-31')
FROM 
 (SELECT
  COALESCE(BANK, 0 ) AS BANK ,
  COALESCE(PRODUCT, 0 ) AS PRODUCT ,
  COALESCE(AU_LMTPRCT, 0 ) AS AU_LMTPRCT ,
  COALESCE(AUTH_OVER, 0 ) AS AUTH_OVER ,
  COALESCE(AUTH_OVERX, 0 ) AS AUTH_OVERX ,
  COALESCE(CA_LMTPRCT, 0 ) AS CA_LMTPRCT ,
  COALESCE(CASH_OVER, 0 ) AS CASH_OVER ,
  COALESCE(CASH_OVERX, 0 ) AS CASH_OVERX ,
  COALESCE(COLIM_MSG, 0 ) AS COLIM_MSG ,
  COALESCE(COLIM_RESP, 0 ) AS COLIM_RESP ,
  COALESCE(DAY_N_ACTI, 0 ) AS DAY_N_ACTI ,
  COALESCE(DAY2_N_ACT, 0 ) AS DAY2_N_ACT ,
  COALESCE(DAY3_N_ACT, 0 ) AS DAY3_N_ACT ,
  COALESCE(EX_AMT_FLG, '' ) AS EX_AMT_FLG ,
  COALESCE(EX_AMT_LOW, 0 ) AS EX_AMT_LOW ,
  COALESCE(EX_PER_DAY, 0 ) AS EX_PER_DAY ,
  COALESCE(EX_PER_MTH, 0 ) AS EX_PER_MTH ,
  COALESCE(FST_CA_MG, 0 ) AS FST_CA_MG ,
  COALESCE(FST_CA_RP, 0 ) AS FST_CA_RP ,
  COALESCE(FST_CACRL, 0 ) AS FST_CACRL ,
  COALESCE(FST_CACRP, 0 ) AS FST_CACRP ,
  COALESCE(FST_PUR_MG, 0 ) AS FST_PUR_MG ,
  COALESCE(FST_PUR_RP, 0 ) AS FST_PUR_RP ,
  COALESCE(FST_PURCRL, 0 ) AS FST_PURCRL ,
  COALESCE(FST_PURCRP, 0 ) AS FST_PURCRP ,
  COALESCE(MARKUP_PCT, 0 ) AS MARKUP_PCT ,
  COALESCE(NO_OLINT, '' ) AS NO_OLINT ,
  COALESCE(OLIM_MSG, 0 ) AS OLIM_MSG ,
  COALESCE(OLIM_RESP, 0 ) AS OLIM_RESP ,
  COALESCE(SMS_LOWAMT, 0 ) AS SMS_LOWAMT ,
  COALESCE(SMS_LOWAMX, 0 ) AS SMS_LOWAMX ,
  COALESCE(MAX_CASH, 0 ) AS MAX_CASH ,
  COALESCE(EC_YN, '' ) AS EC_YN ,
  COALESCE(EC_RESP, 0 ) AS EC_RESP ,
  COALESCE(EC_MSG, 0 ) AS EC_MSG ,
  COALESCE(CC_YN, '' ) AS CC_YN ,
  COALESCE(CC_RSP, 0 ) AS CC_RSP ,
  COALESCE(CC_MSG, 0 ) AS CC_MSG ,
  COALESCE(ECAMT, 0 ) AS ECAMT ,
  COALESCE(ECAMT_RSP, 0 ) AS ECAMT_RSP ,
  COALESCE(ECAMT_MSG, 0 ) AS ECAMT_MSG ,
  COALESCE(CCAMT, 0 ) AS CCAMT ,
  COALESCE(CCAMT_RSP, 0 ) AS CCAMT_RSP ,
  COALESCE(CCAMT_MSG, 0 ) AS CCAMT_MSG ,
  COALESCE(OL_PRCT, 0 ) AS OL_PRCT ,
  COALESCE(DAY4_U_USE, 0 ) AS DAY4_U_USE ,
  COALESCE(MSG_PURCRP, 0 ) AS MSG_PURCRP ,
  COALESCE(YAMT_MIN, 0 ) AS YAMT_MIN ,
  COALESCE(WP_YN, 0 ) AS WP_YN 
 FROM  dw_tdata.CCB_000_PRMAU_${TX_DATE_YYYYMMDD}) N
LEFT JOIN
 (SELECT 
  BANK ,
  PRODUCT ,
  AU_LMTPRCT ,
  AUTH_OVER ,
  AUTH_OVERX ,
  CA_LMTPRCT ,
  CASH_OVER ,
  CASH_OVERX ,
  COLIM_MSG ,
  COLIM_RESP ,
  DAY_N_ACTI ,
  DAY2_N_ACT ,
  DAY3_N_ACT ,
  EX_AMT_FLG ,
  EX_AMT_LOW ,
  EX_PER_DAY ,
  EX_PER_MTH ,
  FST_CA_MG ,
  FST_CA_RP ,
  FST_CACRL ,
  FST_CACRP ,
  FST_PUR_MG ,
  FST_PUR_RP ,
  FST_PURCRL ,
  FST_PURCRP ,
  MARKUP_PCT ,
  NO_OLINT ,
  OLIM_MSG ,
  OLIM_RESP ,
  SMS_LOWAMT ,
  SMS_LOWAMX ,
  MAX_CASH ,
  EC_YN ,
  EC_RESP ,
  EC_MSG ,
  CC_YN ,
  CC_RSP ,
  CC_MSG ,
  ECAMT ,
  ECAMT_RSP ,
  ECAMT_MSG ,
  CCAMT ,
  CCAMT_RSP ,
  CCAMT_MSG ,
  OL_PRCT ,
  DAY4_U_USE ,
  MSG_PURCRP ,
  YAMT_MIN ,
  WP_YN 
 FROM dw_sdata.CCB_000_PRMAU 
 WHERE END_DT = DATE('2100-12-31') ) T
ON N.BANK = T.BANK AND N.PRODUCT = T.PRODUCT
WHERE
(T.BANK IS NULL AND T.PRODUCT IS NULL)
 OR N.AU_LMTPRCT<>T.AU_LMTPRCT
 OR N.AUTH_OVER<>T.AUTH_OVER
 OR N.AUTH_OVERX<>T.AUTH_OVERX
 OR N.CA_LMTPRCT<>T.CA_LMTPRCT
 OR N.CASH_OVER<>T.CASH_OVER
 OR N.CASH_OVERX<>T.CASH_OVERX
 OR N.COLIM_MSG<>T.COLIM_MSG
 OR N.COLIM_RESP<>T.COLIM_RESP
 OR N.DAY_N_ACTI<>T.DAY_N_ACTI
 OR N.DAY2_N_ACT<>T.DAY2_N_ACT
 OR N.DAY3_N_ACT<>T.DAY3_N_ACT
 OR N.EX_AMT_FLG<>T.EX_AMT_FLG
 OR N.EX_AMT_LOW<>T.EX_AMT_LOW
 OR N.EX_PER_DAY<>T.EX_PER_DAY
 OR N.EX_PER_MTH<>T.EX_PER_MTH
 OR N.FST_CA_MG<>T.FST_CA_MG
 OR N.FST_CA_RP<>T.FST_CA_RP
 OR N.FST_CACRL<>T.FST_CACRL
 OR N.FST_CACRP<>T.FST_CACRP
 OR N.FST_PUR_MG<>T.FST_PUR_MG
 OR N.FST_PUR_RP<>T.FST_PUR_RP
 OR N.FST_PURCRL<>T.FST_PURCRL
 OR N.FST_PURCRP<>T.FST_PURCRP
 OR N.MARKUP_PCT<>T.MARKUP_PCT
 OR N.NO_OLINT<>T.NO_OLINT
 OR N.OLIM_MSG<>T.OLIM_MSG
 OR N.OLIM_RESP<>T.OLIM_RESP
 OR N.SMS_LOWAMT<>T.SMS_LOWAMT
 OR N.SMS_LOWAMX<>T.SMS_LOWAMX
 OR N.MAX_CASH<>T.MAX_CASH
 OR N.EC_YN<>T.EC_YN
 OR N.EC_RESP<>T.EC_RESP
 OR N.EC_MSG<>T.EC_MSG
 OR N.CC_YN<>T.CC_YN
 OR N.CC_RSP<>T.CC_RSP
 OR N.CC_MSG<>T.CC_MSG
 OR N.ECAMT<>T.ECAMT
 OR N.ECAMT_RSP<>T.ECAMT_RSP
 OR N.ECAMT_MSG<>T.ECAMT_MSG
 OR N.CCAMT<>T.CCAMT
 OR N.CCAMT_RSP<>T.CCAMT_RSP
 OR N.CCAMT_MSG<>T.CCAMT_MSG
 OR N.OL_PRCT<>T.OL_PRCT
 OR N.DAY4_U_USE<>T.DAY4_U_USE
 OR N.MSG_PURCRP<>T.MSG_PURCRP
 OR N.YAMT_MIN<>T.YAMT_MIN
 OR N.WP_YN<>T.WP_YN
;

--Step3:
UPDATE dw_sdata.CCB_000_PRMAU P 
SET End_Dt=DATE('${TX_DATE_YYYYMMDD}')
FROM T_98
WHERE P.End_Dt=DATE('2100-12-31')
AND P.BANK=T_98.BANK
AND P.PRODUCT=T_98.PRODUCT
;

--Step4:
INSERT  INTO dw_sdata.CCB_000_PRMAU SELECT * FROM T_98;

COMMIT;

ENDOFINPUT

  close(VSQL);

  my $RET_CODE = $? >> 8;

  if ( $RET_CODE == 0 ) {
      return 0;
  }
  else {
      return 1;
  }
}

# ------------ main function ------------
sub main
{
   my $ret;
   open(LOGONFILE_H, "${LOGON_FILE}");
   ${LOGON_STR} = <LOGONFILE_H>;
   close(LOGONFILE_H);
   
   # Get the decoded logon string
   my($user,$passwd) = split(',',${LOGON_STR}); 
   #my $decodepasswd = `${AUTO_HOME}/bin/IceCode.exe -d "$passwd" "$user"`;                     
   #${LOGON_STR} = "|vsql -h 192.168.2.44 -p 5433 -d CPCIMDB -U ".$user." -w ".$decodepasswd;

   # Call vsql command to load data
   $ret = run_vsql_command();

   print "run_vsql_command() = $ret";
   return $ret;
}

# ------------ program section ------------
if ( $#ARGV < 0 ) {
   print "Usage: [perl ������ Control_File] (Control_File format: dir.jobnameYYYYMMDD or sysname_jobname_YYYYMMDD.dir) 
";
   print "
";
   exit(1);
}

# Get the first argument
${CONTROL_FILE} = $ARGV[0];

if (${CONTROL_FILE} =~/[0-9]{8}($|\.)/) {
   ${TX_DATE_YYYYMMDD} = substr($&,0,8);
}
else{
   print "Usage: [perl ������ Control_File] (Control_File format: dir.jobnameYYYYMMDD or sysname_jobname_YYYYMMDD.dir) 
";
   print "
";
   exit(1);
}

${TX_MON_DAY_MMDD} = substr(${TX_DATE_YYYYMMDD}, length(${TX_DATE_YYYYMMDD})-4,4);
${TX_DATE} = substr(${TX_DATE_YYYYMMDD}, 0, 4)."-".substr(${TX_DATE_YYYYMMDD}, 4, 2)."-".substr(${TX_DATE_YYYYMMDD}, 6, 2);
open(STDERR, ">&STDOUT");

my $ret = main();

exit($ret);
