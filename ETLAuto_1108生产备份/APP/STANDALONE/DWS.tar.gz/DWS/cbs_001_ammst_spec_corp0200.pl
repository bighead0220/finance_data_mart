#!/usr/bin/perl

use strict;     # Declare using Perl strict syntax
use DBI;        # If you are using other package, declare here

# ------------ Variable Section ------------
my ${AUTO_HOME} = $ENV{"AUTO_HOME"};

my ${WML_DB} = $ENV{"AUTO_WML_DB"};
if ( !defined(${WML_DB}) ) {
    ${WML_DB} = "WML";
}
my ${WTL_DB} = $ENV{"AUTO_WTL_DB"};
if ( !defined(${WTL_DB}) ) {
    ${WTL_DB} = "WTL";
}
my ${WMLVIEW_DB} = $ENV{"AUTO_WMLVIEW_DB"};
if ( !defined(${WMLVIEW_DB}) ) {
    ${WMLVIEW_DB} = "WMLVIEW";
}
my ${WTLVIEW_DB} = $ENV{"AUTO_WTLVIEW_DB"};
if ( !defined(${WTLVIEW_DB}) ) {
    ${WTLVIEW_DB} = "WTLVIEW";
}

my ${NULL_DATE} = "1900-01-02";
my ${MIN_DATE} = "1900-01-01";
my ${MAX_DATE} = "2100-12-31";

my ${LOGON_FILE} = "${AUTO_HOME}/etc/VERTICA_LOGON";
my ${LOGON_STR};
my ${CONTROL_FILE};
my ${TX_DATE};
my ${TX_DATE_YYYYMMDD};
my ${TX_MON_DAY_MMDD};

# ------------ VSQL function ------------
sub run_vsql_command
{
  #my $rc = open(VSQL, "${LOGON_STR}");
  my $rc = open(VSQL, "|vsql -h 22.224.65.2 -p 5433 -d CPCIMDB -U dwpsbc -w dwpsbc2016");

  unless ($rc) {
      print "Could not invoke VSQL command
";
      return -1;
  }

# ------ Below are VSQL scripts ----------
  print VSQL <<ENDOFINPUT;

\\set ON_ERROR_STOP on

--Step0:
DELETE FROM dw_sdata.CBS_001_AMMST_SPEC_CORP WHERE start_dt>=DATE('${TX_DATE_YYYYMMDD}');
UPDATE dw_sdata.CBS_001_AMMST_SPEC_CORP SET end_dt=DATE('2100-12-31') WHERE end_dt>=DATE('${TX_DATE_YYYYMMDD}') AND end_dt<>DATE('2100-12-31');

--Step1:
CREATE LOCAL TEMPORARY TABLE  T_72 ON COMMIT PRESERVE ROWS AS SELECT * FROM dw_sdata.CBS_001_AMMST_SPEC_CORP WHERE 1=0;

--Step2:
INSERT  INTO T_72 (
  ACCOUNT,
  OPEN_UNIT,
  CUR_CODE,
  ACCT_ATTR,
  ACCT_NAME,
  YDAY_BAL,
  LCV_HCUR_BAL,
  YDAY_BAL_FLAG,
  CUR_BAL,
  CV_HCUR_BAL,
  BAL_FLAG,
  ACCT_STATE,
  OPEN_DATE,
  INT_START_DATE,
  LAST_CI_DATE,
  LID_TO_NOW_IWEIT,
  PREP_I_FLAG,
  I_FLAG,
  INT_DATE,
  I_MTHD,
  IRATE_KIND,
  IRATE_LEVEL,
  IRATE_CODE,
  IRATE_FLOAT_TYPE,
  FLOAT_IRATE,
  FLOAT_POINTS,
  IRATE,
  OVRD_FLAG,
  OVRD_INTCODE,
  PRTOVR_PAGERS,
  NO_PRT_CNT,
  LST_CLR_DATE,
  LST_OCC_DATE,
  TIME_STAMP,
  STATUS_FLAG,
  TIN_ACCT,
  DAC,
  start_dt,
  end_dt)
SELECT
  N.ACCOUNT,
  N.OPEN_UNIT,
  N.CUR_CODE,
  N.ACCT_ATTR,
  N.ACCT_NAME,
  N.YDAY_BAL,
  N.LCV_HCUR_BAL,
  N.YDAY_BAL_FLAG,
  N.CUR_BAL,
  N.CV_HCUR_BAL,
  N.BAL_FLAG,
  N.ACCT_STATE,
  N.OPEN_DATE,
  N.INT_START_DATE,
  N.LAST_CI_DATE,
  N.LID_TO_NOW_IWEIT,
  N.PREP_I_FLAG,
  N.I_FLAG,
  N.INT_DATE,
  N.I_MTHD,
  N.IRATE_KIND,
  N.IRATE_LEVEL,
  N.IRATE_CODE,
  N.IRATE_FLOAT_TYPE,
  N.FLOAT_IRATE,
  N.FLOAT_POINTS,
  N.IRATE,
  N.OVRD_FLAG,
  N.OVRD_INTCODE,
  N.PRTOVR_PAGERS,
  N.NO_PRT_CNT,
  N.LST_CLR_DATE,
  N.LST_OCC_DATE,
  N.TIME_STAMP,
  N.STATUS_FLAG,
  N.TIN_ACCT,
  N.DAC,
  DATE('${TX_DATE_YYYYMMDD}'),
  DATE('2100-12-31')
FROM 
 (SELECT
  COALESCE(ACCOUNT, '' ) AS ACCOUNT ,
  COALESCE(OPEN_UNIT, '' ) AS OPEN_UNIT ,
  COALESCE(CUR_CODE, '' ) AS CUR_CODE ,
  COALESCE(ACCT_ATTR, '' ) AS ACCT_ATTR ,
  COALESCE(ACCT_NAME, '' ) AS ACCT_NAME ,
  COALESCE(YDAY_BAL, 0 ) AS YDAY_BAL ,
  COALESCE(LCV_HCUR_BAL, 0 ) AS LCV_HCUR_BAL ,
  COALESCE(YDAY_BAL_FLAG, '' ) AS YDAY_BAL_FLAG ,
  COALESCE(CUR_BAL, 0 ) AS CUR_BAL ,
  COALESCE(CV_HCUR_BAL, 0 ) AS CV_HCUR_BAL ,
  COALESCE(BAL_FLAG, '' ) AS BAL_FLAG ,
  COALESCE(ACCT_STATE, '' ) AS ACCT_STATE ,
  COALESCE(OPEN_DATE, '' ) AS OPEN_DATE ,
  COALESCE(INT_START_DATE, '' ) AS INT_START_DATE ,
  COALESCE(LAST_CI_DATE, '' ) AS LAST_CI_DATE ,
  COALESCE(LID_TO_NOW_IWEIT, 0 ) AS LID_TO_NOW_IWEIT ,
  COALESCE(PREP_I_FLAG, '' ) AS PREP_I_FLAG ,
  COALESCE(I_FLAG, '' ) AS I_FLAG ,
  COALESCE(INT_DATE, '' ) AS INT_DATE ,
  COALESCE(I_MTHD, '' ) AS I_MTHD ,
  COALESCE(IRATE_KIND, '' ) AS IRATE_KIND ,
  COALESCE(IRATE_LEVEL, '' ) AS IRATE_LEVEL ,
  COALESCE(IRATE_CODE, '' ) AS IRATE_CODE ,
  COALESCE(IRATE_FLOAT_TYPE, '' ) AS IRATE_FLOAT_TYPE ,
  COALESCE(FLOAT_IRATE, 0 ) AS FLOAT_IRATE ,
  COALESCE(FLOAT_POINTS, 0 ) AS FLOAT_POINTS ,
  COALESCE(IRATE, 0 ) AS IRATE ,
  COALESCE(OVRD_FLAG, '' ) AS OVRD_FLAG ,
  COALESCE(OVRD_INTCODE, '' ) AS OVRD_INTCODE ,
  COALESCE(PRTOVR_PAGERS, 0 ) AS PRTOVR_PAGERS ,
  COALESCE(NO_PRT_CNT, 0 ) AS NO_PRT_CNT ,
  COALESCE(LST_CLR_DATE, '' ) AS LST_CLR_DATE ,
  COALESCE(LST_OCC_DATE, '' ) AS LST_OCC_DATE ,
  COALESCE(TIME_STAMP, '' ) AS TIME_STAMP ,
  COALESCE(STATUS_FLAG, '' ) AS STATUS_FLAG ,
  COALESCE(TIN_ACCT, '' ) AS TIN_ACCT ,
  COALESCE(DAC, '' ) AS DAC 
 FROM  dw_tdata.CBS_001_AMMST_SPEC_CORP_${TX_DATE_YYYYMMDD}) N
LEFT JOIN
 (SELECT 
  ACCOUNT ,
  OPEN_UNIT ,
  CUR_CODE ,
  ACCT_ATTR ,
  ACCT_NAME ,
  YDAY_BAL ,
  LCV_HCUR_BAL ,
  YDAY_BAL_FLAG ,
  CUR_BAL ,
  CV_HCUR_BAL ,
  BAL_FLAG ,
  ACCT_STATE ,
  OPEN_DATE ,
  INT_START_DATE ,
  LAST_CI_DATE ,
  LID_TO_NOW_IWEIT ,
  PREP_I_FLAG ,
  I_FLAG ,
  INT_DATE ,
  I_MTHD ,
  IRATE_KIND ,
  IRATE_LEVEL ,
  IRATE_CODE ,
  IRATE_FLOAT_TYPE ,
  FLOAT_IRATE ,
  FLOAT_POINTS ,
  IRATE ,
  OVRD_FLAG ,
  OVRD_INTCODE ,
  PRTOVR_PAGERS ,
  NO_PRT_CNT ,
  LST_CLR_DATE ,
  LST_OCC_DATE ,
  TIME_STAMP ,
  STATUS_FLAG ,
  TIN_ACCT ,
  DAC 
 FROM dw_sdata.CBS_001_AMMST_SPEC_CORP 
 WHERE END_DT = DATE('2100-12-31') ) T
ON N.ACCOUNT = T.ACCOUNT
WHERE
(T.ACCOUNT IS NULL)
 OR N.OPEN_UNIT<>T.OPEN_UNIT
 OR N.CUR_CODE<>T.CUR_CODE
 OR N.ACCT_ATTR<>T.ACCT_ATTR
 OR N.ACCT_NAME<>T.ACCT_NAME
 OR N.YDAY_BAL<>T.YDAY_BAL
 OR N.LCV_HCUR_BAL<>T.LCV_HCUR_BAL
 OR N.YDAY_BAL_FLAG<>T.YDAY_BAL_FLAG
 OR N.CUR_BAL<>T.CUR_BAL
 OR N.CV_HCUR_BAL<>T.CV_HCUR_BAL
 OR N.BAL_FLAG<>T.BAL_FLAG
 OR N.ACCT_STATE<>T.ACCT_STATE
 OR N.OPEN_DATE<>T.OPEN_DATE
 OR N.INT_START_DATE<>T.INT_START_DATE
 OR N.LAST_CI_DATE<>T.LAST_CI_DATE
 OR N.LID_TO_NOW_IWEIT<>T.LID_TO_NOW_IWEIT
 OR N.PREP_I_FLAG<>T.PREP_I_FLAG
 OR N.I_FLAG<>T.I_FLAG
 OR N.INT_DATE<>T.INT_DATE
 OR N.I_MTHD<>T.I_MTHD
 OR N.IRATE_KIND<>T.IRATE_KIND
 OR N.IRATE_LEVEL<>T.IRATE_LEVEL
 OR N.IRATE_CODE<>T.IRATE_CODE
 OR N.IRATE_FLOAT_TYPE<>T.IRATE_FLOAT_TYPE
 OR N.FLOAT_IRATE<>T.FLOAT_IRATE
 OR N.FLOAT_POINTS<>T.FLOAT_POINTS
 OR N.IRATE<>T.IRATE
 OR N.OVRD_FLAG<>T.OVRD_FLAG
 OR N.OVRD_INTCODE<>T.OVRD_INTCODE
 OR N.PRTOVR_PAGERS<>T.PRTOVR_PAGERS
 OR N.NO_PRT_CNT<>T.NO_PRT_CNT
 OR N.LST_CLR_DATE<>T.LST_CLR_DATE
 OR N.LST_OCC_DATE<>T.LST_OCC_DATE
 OR N.TIME_STAMP<>T.TIME_STAMP
 OR N.STATUS_FLAG<>T.STATUS_FLAG
 OR N.TIN_ACCT<>T.TIN_ACCT
 OR N.DAC<>T.DAC
;

--Step3:
UPDATE dw_sdata.CBS_001_AMMST_SPEC_CORP P 
SET End_Dt=DATE('${TX_DATE_YYYYMMDD}')
FROM T_72
WHERE P.End_Dt=DATE('2100-12-31')
AND P.ACCOUNT=T_72.ACCOUNT
;

--Step4:
INSERT  INTO dw_sdata.CBS_001_AMMST_SPEC_CORP SELECT * FROM T_72;

COMMIT;

ENDOFINPUT

  close(VSQL);

  my $RET_CODE = $? >> 8;

  if ( $RET_CODE == 0 ) {
      return 0;
  }
  else {
      return 1;
  }
}

# ------------ main function ------------
sub main
{
   my $ret;
   open(LOGONFILE_H, "${LOGON_FILE}");
   ${LOGON_STR} = <LOGONFILE_H>;
   close(LOGONFILE_H);
   
   # Get the decoded logon string
   my($user,$passwd) = split(',',${LOGON_STR}); 
   #my $decodepasswd = `${AUTO_HOME}/bin/IceCode.exe -d "$passwd" "$user"`;                     
   #${LOGON_STR} = "|vsql -h 192.168.2.44 -p 5433 -d CPCIMDB -U ".$user." -w ".$decodepasswd;

   # Call vsql command to load data
   $ret = run_vsql_command();

   print "run_vsql_command() = $ret";
   return $ret;
}

# ------------ program section ------------
if ( $#ARGV < 0 ) {
   print "Usage: [perl ������ Control_File] (Control_File format: dir.jobnameYYYYMMDD or sysname_jobname_YYYYMMDD.dir) 
";
   print "
";
   exit(1);
}

# Get the first argument
${CONTROL_FILE} = $ARGV[0];

if (${CONTROL_FILE} =~/[0-9]{8}($|\.)/) {
   ${TX_DATE_YYYYMMDD} = substr($&,0,8);
}
else{
   print "Usage: [perl ������ Control_File] (Control_File format: dir.jobnameYYYYMMDD or sysname_jobname_YYYYMMDD.dir) 
";
   print "
";
   exit(1);
}

${TX_MON_DAY_MMDD} = substr(${TX_DATE_YYYYMMDD}, length(${TX_DATE_YYYYMMDD})-4,4);
${TX_DATE} = substr(${TX_DATE_YYYYMMDD}, 0, 4)."-".substr(${TX_DATE_YYYYMMDD}, 4, 2)."-".substr(${TX_DATE_YYYYMMDD}, 6, 2);
open(STDERR, ">&STDOUT");

my $ret = main();

exit($ret);
