#!/usr/bin/perl

use strict;     # Declare using Perl strict syntax
use DBI;        # If you are using other package, declare here

# ------------ Variable Section ------------
my ${AUTO_HOME} = $ENV{"AUTO_HOME"};

my ${WML_DB} = $ENV{"AUTO_WML_DB"};
if ( !defined(${WML_DB}) ) {
    ${WML_DB} = "WML";
}
my ${WTL_DB} = $ENV{"AUTO_WTL_DB"};
if ( !defined(${WTL_DB}) ) {
    ${WTL_DB} = "WTL";
}
my ${WMLVIEW_DB} = $ENV{"AUTO_WMLVIEW_DB"};
if ( !defined(${WMLVIEW_DB}) ) {
    ${WMLVIEW_DB} = "WMLVIEW";
}
my ${WTLVIEW_DB} = $ENV{"AUTO_WTLVIEW_DB"};
if ( !defined(${WTLVIEW_DB}) ) {
    ${WTLVIEW_DB} = "WTLVIEW";
}

my ${NULL_DATE} = "1900-01-02";
my ${MIN_DATE} = "1900-01-01";
my ${MAX_DATE} = "2100-12-31";

my ${LOGON_FILE} = "${AUTO_HOME}/etc/VERTICA_LOGON";
my ${LOGON_STR};
my ${CONTROL_FILE};
my ${TX_DATE};
my ${TX_DATE_YYYYMMDD};
my ${TX_MON_DAY_MMDD};

# ------------ VSQL function ------------
sub run_vsql_command
{
  #my $rc = open(VSQL, "${LOGON_STR}");
  my $rc = open(VSQL, "|vsql -h 22.224.65.2 -p 5433 -d CPCIMDB -U dwpsbc -w dwpsbc2016");

  unless ($rc) {
      print "Could not invoke VSQL command
";
      return -1;
  }

# ------ Below are VSQL scripts ----------
  print VSQL <<ENDOFINPUT;

\\set ON_ERROR_STOP on

--Step0:
DELETE FROM dw_sdata.CCS_006_RAPF91 WHERE start_dt>=DATE('${TX_DATE_YYYYMMDD}');
UPDATE dw_sdata.CCS_006_RAPF91 SET end_dt=DATE('2100-12-31') WHERE end_dt>=DATE('${TX_DATE_YYYYMMDD}') AND end_dt<>DATE('2100-12-31');

--Step1:
CREATE LOCAL TEMPORARY TABLE  T_138 ON COMMIT PRESERVE ROWS AS SELECT * FROM dw_sdata.CCS_006_RAPF91 WHERE 1=0;

--Step2:
INSERT  INTO T_138 (
  RA91PRE,
  RA91DPNOK,
  RA91DPNOA,
  RA91DUEBNO,
  RA91LNCLS,
  RA91TRFROM,
  RA91DOCNT,
  RA91TIMES,
  RA91EFCCNT,
  RA91STDATE,
  RA91ENDDT,
  RA91BQTSBJ,
  RA91BQTSLX,
  RA91BTXAMT,
  RA91LZBJ,
  RA91BQYSLX,
  RA91SPFLAG,
  RA91LVBG,
  RA91LVCGOK,
  RA91SPDATE,
  RA91SGFLAG,
  RA91SGDATE,
  RA91ISOK,
  RA91ISZERO,
  RA91FNDATE,
  RA91BZ1,
  RA91BZ2,
  start_dt,
  end_dt)
SELECT
  N.RA91PRE,
  N.RA91DPNOK,
  N.RA91DPNOA,
  N.RA91DUEBNO,
  N.RA91LNCLS,
  N.RA91TRFROM,
  N.RA91DOCNT,
  N.RA91TIMES,
  N.RA91EFCCNT,
  N.RA91STDATE,
  N.RA91ENDDT,
  N.RA91BQTSBJ,
  N.RA91BQTSLX,
  N.RA91BTXAMT,
  N.RA91LZBJ,
  N.RA91BQYSLX,
  N.RA91SPFLAG,
  N.RA91LVBG,
  N.RA91LVCGOK,
  N.RA91SPDATE,
  N.RA91SGFLAG,
  N.RA91SGDATE,
  N.RA91ISOK,
  N.RA91ISZERO,
  N.RA91FNDATE,
  N.RA91BZ1,
  N.RA91BZ2,
  DATE('${TX_DATE_YYYYMMDD}'),
  DATE('2100-12-31')
FROM 
 (SELECT
  COALESCE(RA91PRE, '' ) AS RA91PRE ,
  COALESCE(RA91DPNOK, '' ) AS RA91DPNOK ,
  COALESCE(RA91DPNOA, '' ) AS RA91DPNOA ,
  COALESCE(RA91DUEBNO, '' ) AS RA91DUEBNO ,
  COALESCE(RA91LNCLS, '' ) AS RA91LNCLS ,
  COALESCE(RA91TRFROM, '' ) AS RA91TRFROM ,
  COALESCE(RA91DOCNT, 0 ) AS RA91DOCNT ,
  COALESCE(RA91TIMES, 0 ) AS RA91TIMES ,
  COALESCE(RA91EFCCNT, 0 ) AS RA91EFCCNT ,
  COALESCE(RA91STDATE, '' ) AS RA91STDATE ,
  COALESCE(RA91ENDDT, '' ) AS RA91ENDDT ,
  COALESCE(RA91BQTSBJ, 0 ) AS RA91BQTSBJ ,
  COALESCE(RA91BQTSLX, 0 ) AS RA91BQTSLX ,
  COALESCE(RA91BTXAMT, 0 ) AS RA91BTXAMT ,
  COALESCE(RA91LZBJ, 0 ) AS RA91LZBJ ,
  COALESCE(RA91BQYSLX, 0 ) AS RA91BQYSLX ,
  COALESCE(RA91SPFLAG, '' ) AS RA91SPFLAG ,
  COALESCE(RA91LVBG, '' ) AS RA91LVBG ,
  COALESCE(RA91LVCGOK, 0 ) AS RA91LVCGOK ,
  COALESCE(RA91SPDATE, '' ) AS RA91SPDATE ,
  COALESCE(RA91SGFLAG, '' ) AS RA91SGFLAG ,
  COALESCE(RA91SGDATE, '' ) AS RA91SGDATE ,
  COALESCE(RA91ISOK, '' ) AS RA91ISOK ,
  COALESCE(RA91ISZERO, '' ) AS RA91ISZERO ,
  COALESCE(RA91FNDATE, '' ) AS RA91FNDATE ,
  COALESCE(RA91BZ1, 0 ) AS RA91BZ1 ,
  COALESCE(RA91BZ2, '' ) AS RA91BZ2 
 FROM  dw_tdata.CCS_006_RAPF91_${TX_DATE_YYYYMMDD}) N
LEFT JOIN
 (SELECT 
  RA91PRE ,
  RA91DPNOK ,
  RA91DPNOA ,
  RA91DUEBNO ,
  RA91LNCLS ,
  RA91TRFROM ,
  RA91DOCNT ,
  RA91TIMES ,
  RA91EFCCNT ,
  RA91STDATE ,
  RA91ENDDT ,
  RA91BQTSBJ ,
  RA91BQTSLX ,
  RA91BTXAMT ,
  RA91LZBJ ,
  RA91BQYSLX ,
  RA91SPFLAG ,
  RA91LVBG ,
  RA91LVCGOK ,
  RA91SPDATE ,
  RA91SGFLAG ,
  RA91SGDATE ,
  RA91ISOK ,
  RA91ISZERO ,
  RA91FNDATE ,
  RA91BZ1 ,
  RA91BZ2 
 FROM dw_sdata.CCS_006_RAPF91 
 WHERE END_DT = DATE('2100-12-31') ) T
ON N.RA91DUEBNO = T.RA91DUEBNO
WHERE
(T.RA91DUEBNO IS NULL)
 OR N.RA91PRE<>T.RA91PRE
 OR N.RA91DPNOK<>T.RA91DPNOK
 OR N.RA91DPNOA<>T.RA91DPNOA
 OR N.RA91LNCLS<>T.RA91LNCLS
 OR N.RA91TRFROM<>T.RA91TRFROM
 OR N.RA91DOCNT<>T.RA91DOCNT
 OR N.RA91TIMES<>T.RA91TIMES
 OR N.RA91EFCCNT<>T.RA91EFCCNT
 OR N.RA91STDATE<>T.RA91STDATE
 OR N.RA91ENDDT<>T.RA91ENDDT
 OR N.RA91BQTSBJ<>T.RA91BQTSBJ
 OR N.RA91BQTSLX<>T.RA91BQTSLX
 OR N.RA91BTXAMT<>T.RA91BTXAMT
 OR N.RA91LZBJ<>T.RA91LZBJ
 OR N.RA91BQYSLX<>T.RA91BQYSLX
 OR N.RA91SPFLAG<>T.RA91SPFLAG
 OR N.RA91LVBG<>T.RA91LVBG
 OR N.RA91LVCGOK<>T.RA91LVCGOK
 OR N.RA91SPDATE<>T.RA91SPDATE
 OR N.RA91SGFLAG<>T.RA91SGFLAG
 OR N.RA91SGDATE<>T.RA91SGDATE
 OR N.RA91ISOK<>T.RA91ISOK
 OR N.RA91ISZERO<>T.RA91ISZERO
 OR N.RA91FNDATE<>T.RA91FNDATE
 OR N.RA91BZ1<>T.RA91BZ1
 OR N.RA91BZ2<>T.RA91BZ2
;

--Step3:
UPDATE dw_sdata.CCS_006_RAPF91 P 
SET End_Dt=DATE('${TX_DATE_YYYYMMDD}')
FROM T_138
WHERE P.End_Dt=DATE('2100-12-31')
AND P.RA91DUEBNO=T_138.RA91DUEBNO
;

--Step4:
INSERT  INTO dw_sdata.CCS_006_RAPF91 SELECT * FROM T_138;

COMMIT;

ENDOFINPUT

  close(VSQL);

  my $RET_CODE = $? >> 8;

  if ( $RET_CODE == 0 ) {
      return 0;
  }
  else {
      return 1;
  }
}

# ------------ main function ------------
sub main
{
   my $ret;
   open(LOGONFILE_H, "${LOGON_FILE}");
   ${LOGON_STR} = <LOGONFILE_H>;
   close(LOGONFILE_H);
   
   # Get the decoded logon string
   my($user,$passwd) = split(',',${LOGON_STR}); 
   #my $decodepasswd = `${AUTO_HOME}/bin/IceCode.exe -d "$passwd" "$user"`;                     
   #${LOGON_STR} = "|vsql -h 192.168.2.44 -p 5433 -d CPCIMDB -U ".$user." -w ".$decodepasswd;

   # Call vsql command to load data
   $ret = run_vsql_command();

   print "run_vsql_command() = $ret";
   return $ret;
}

# ------------ program section ------------
if ( $#ARGV < 0 ) {
   print "Usage: [perl ������ Control_File] (Control_File format: dir.jobnameYYYYMMDD or sysname_jobname_YYYYMMDD.dir) 
";
   print "
";
   exit(1);
}

# Get the first argument
${CONTROL_FILE} = $ARGV[0];

if (${CONTROL_FILE} =~/[0-9]{8}($|\.)/) {
   ${TX_DATE_YYYYMMDD} = substr($&,0,8);
}
else{
   print "Usage: [perl ������ Control_File] (Control_File format: dir.jobnameYYYYMMDD or sysname_jobname_YYYYMMDD.dir) 
";
   print "
";
   exit(1);
}

${TX_MON_DAY_MMDD} = substr(${TX_DATE_YYYYMMDD}, length(${TX_DATE_YYYYMMDD})-4,4);
${TX_DATE} = substr(${TX_DATE_YYYYMMDD}, 0, 4)."-".substr(${TX_DATE_YYYYMMDD}, 4, 2)."-".substr(${TX_DATE_YYYYMMDD}, 6, 2);
open(STDERR, ">&STDOUT");

my $ret = main();

exit($ret);
