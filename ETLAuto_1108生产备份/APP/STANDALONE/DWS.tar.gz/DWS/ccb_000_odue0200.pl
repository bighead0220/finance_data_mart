#!/usr/bin/perl

use strict;     # Declare using Perl strict syntax
use DBI;        # If you are using other package, declare here

# ------------ Variable Section ------------
my ${AUTO_HOME} = $ENV{"AUTO_HOME"};

my ${WML_DB} = $ENV{"AUTO_WML_DB"};
if ( !defined(${WML_DB}) ) {
    ${WML_DB} = "WML";
}
my ${WTL_DB} = $ENV{"AUTO_WTL_DB"};
if ( !defined(${WTL_DB}) ) {
    ${WTL_DB} = "WTL";
}
my ${WMLVIEW_DB} = $ENV{"AUTO_WMLVIEW_DB"};
if ( !defined(${WMLVIEW_DB}) ) {
    ${WMLVIEW_DB} = "WMLVIEW";
}
my ${WTLVIEW_DB} = $ENV{"AUTO_WTLVIEW_DB"};
if ( !defined(${WTLVIEW_DB}) ) {
    ${WTLVIEW_DB} = "WTLVIEW";
}

my ${NULL_DATE} = "1900-01-02";
my ${MIN_DATE} = "1900-01-01";
my ${MAX_DATE} = "2100-12-31";

my ${LOGON_FILE} = "${AUTO_HOME}/etc/VERTICA_LOGON";
my ${LOGON_STR};
my ${CONTROL_FILE};
my ${TX_DATE};
my ${TX_DATE_YYYYMMDD};
my ${TX_MON_DAY_MMDD};

# ------------ VSQL function ------------
sub run_vsql_command
{
  #my $rc = open(VSQL, "${LOGON_STR}");
  my $rc = open(VSQL, "|vsql -h 22.224.65.2 -p 5433 -d CPCIMDB -U dwpsbc -w dwpsbc2016");

  unless ($rc) {
      print "Could not invoke VSQL command
";
      return -1;
  }

# ------ Below are VSQL scripts ----------
  print VSQL <<ENDOFINPUT;

\\set ON_ERROR_STOP on

--Step0:
DELETE FROM dw_sdata.CCB_000_ODUE WHERE start_dt>=DATE('${TX_DATE_YYYYMMDD}');
UPDATE dw_sdata.CCB_000_ODUE SET end_dt=DATE('2100-12-31') WHERE end_dt>=DATE('${TX_DATE_YYYYMMDD}') AND end_dt<>DATE('2100-12-31');

--Step1:
CREATE LOCAL TEMPORARY TABLE  T_349 ON COMMIT PRESERVE ROWS AS SELECT * FROM dw_sdata.CCB_000_ODUE WHERE 1=0;

--Step2:
INSERT  INTO T_349 (
  BANK,
  ACCOUNT,
  BRANCH,
  CATEGORY,
  CURR_NUM,
  INP_DAY,
  DRAFT_DAY,
  MONTH_NBR,
  ODUE_FLAG,
  INP_BAL,
  INP_BALORI,
  REM_BAL,
  REM_BALORI,
  LAST_PAYMT,
  INP_TIME,
  INP_NOINT,
  REM_NOINT,
  INP_NINT01,
  INP_NINT02,
  INP_NINT03,
  INP_NINT04,
  INP_NINT05,
  INP_NINT06,
  INP_NINT07,
  INP_NINT08,
  INP_NINT09,
  INP_NINT10,
  REM_NINT01,
  REM_NINT02,
  REM_NINT03,
  REM_NINT04,
  REM_NINT05,
  REM_NINT06,
  REM_NINT07,
  REM_NINT08,
  REM_NINT09,
  REM_NINT10,
  start_dt,
  end_dt)
SELECT
  N.BANK,
  N.ACCOUNT,
  N.BRANCH,
  N.CATEGORY,
  N.CURR_NUM,
  N.INP_DAY,
  N.DRAFT_DAY,
  N.MONTH_NBR,
  N.ODUE_FLAG,
  N.INP_BAL,
  N.INP_BALORI,
  N.REM_BAL,
  N.REM_BALORI,
  N.LAST_PAYMT,
  N.INP_TIME,
  N.INP_NOINT,
  N.REM_NOINT,
  N.INP_NINT01,
  N.INP_NINT02,
  N.INP_NINT03,
  N.INP_NINT04,
  N.INP_NINT05,
  N.INP_NINT06,
  N.INP_NINT07,
  N.INP_NINT08,
  N.INP_NINT09,
  N.INP_NINT10,
  N.REM_NINT01,
  N.REM_NINT02,
  N.REM_NINT03,
  N.REM_NINT04,
  N.REM_NINT05,
  N.REM_NINT06,
  N.REM_NINT07,
  N.REM_NINT08,
  N.REM_NINT09,
  N.REM_NINT10,
  DATE('${TX_DATE_YYYYMMDD}'),
  DATE('2100-12-31')
FROM 
 (SELECT
  COALESCE(BANK, 0 ) AS BANK ,
  COALESCE(ACCOUNT, 0 ) AS ACCOUNT ,
  COALESCE(BRANCH, 0 ) AS BRANCH ,
  COALESCE(CATEGORY, 0 ) AS CATEGORY ,
  COALESCE(CURR_NUM, 0 ) AS CURR_NUM ,
  COALESCE(INP_DAY, 0 ) AS INP_DAY ,
  COALESCE(DRAFT_DAY, 0 ) AS DRAFT_DAY ,
  COALESCE(MONTH_NBR, 0 ) AS MONTH_NBR ,
  COALESCE(ODUE_FLAG, 0 ) AS ODUE_FLAG ,
  COALESCE(INP_BAL, 0 ) AS INP_BAL ,
  COALESCE(INP_BALORI, 0 ) AS INP_BALORI ,
  COALESCE(REM_BAL, 0 ) AS REM_BAL ,
  COALESCE(REM_BALORI, 0 ) AS REM_BALORI ,
  COALESCE(LAST_PAYMT, 0 ) AS LAST_PAYMT ,
  COALESCE(INP_TIME, 0 ) AS INP_TIME ,
  COALESCE(INP_NOINT, 0 ) AS INP_NOINT ,
  COALESCE(REM_NOINT, 0 ) AS REM_NOINT ,
  COALESCE(INP_NINT01, 0 ) AS INP_NINT01 ,
  COALESCE(INP_NINT02, 0 ) AS INP_NINT02 ,
  COALESCE(INP_NINT03, 0 ) AS INP_NINT03 ,
  COALESCE(INP_NINT04, 0 ) AS INP_NINT04 ,
  COALESCE(INP_NINT05, 0 ) AS INP_NINT05 ,
  COALESCE(INP_NINT06, 0 ) AS INP_NINT06 ,
  COALESCE(INP_NINT07, 0 ) AS INP_NINT07 ,
  COALESCE(INP_NINT08, 0 ) AS INP_NINT08 ,
  COALESCE(INP_NINT09, 0 ) AS INP_NINT09 ,
  COALESCE(INP_NINT10, 0 ) AS INP_NINT10 ,
  COALESCE(REM_NINT01, 0 ) AS REM_NINT01 ,
  COALESCE(REM_NINT02, 0 ) AS REM_NINT02 ,
  COALESCE(REM_NINT03, 0 ) AS REM_NINT03 ,
  COALESCE(REM_NINT04, 0 ) AS REM_NINT04 ,
  COALESCE(REM_NINT05, 0 ) AS REM_NINT05 ,
  COALESCE(REM_NINT06, 0 ) AS REM_NINT06 ,
  COALESCE(REM_NINT07, 0 ) AS REM_NINT07 ,
  COALESCE(REM_NINT08, 0 ) AS REM_NINT08 ,
  COALESCE(REM_NINT09, 0 ) AS REM_NINT09 ,
  COALESCE(REM_NINT10, 0 ) AS REM_NINT10 
 FROM  dw_tdata.CCB_000_ODUE_${TX_DATE_YYYYMMDD}) N
LEFT JOIN
 (SELECT 
  BANK ,
  ACCOUNT ,
  BRANCH ,
  CATEGORY ,
  CURR_NUM ,
  INP_DAY ,
  DRAFT_DAY ,
  MONTH_NBR ,
  ODUE_FLAG ,
  INP_BAL ,
  INP_BALORI ,
  REM_BAL ,
  REM_BALORI ,
  LAST_PAYMT ,
  INP_TIME ,
  INP_NOINT ,
  REM_NOINT ,
  INP_NINT01 ,
  INP_NINT02 ,
  INP_NINT03 ,
  INP_NINT04 ,
  INP_NINT05 ,
  INP_NINT06 ,
  INP_NINT07 ,
  INP_NINT08 ,
  INP_NINT09 ,
  INP_NINT10 ,
  REM_NINT01 ,
  REM_NINT02 ,
  REM_NINT03 ,
  REM_NINT04 ,
  REM_NINT05 ,
  REM_NINT06 ,
  REM_NINT07 ,
  REM_NINT08 ,
  REM_NINT09 ,
  REM_NINT10 
 FROM dw_sdata.CCB_000_ODUE 
 WHERE END_DT = DATE('2100-12-31') ) T
ON N.ACCOUNT = T.ACCOUNT AND N.CURR_NUM = T.CURR_NUM AND N.MONTH_NBR = T.MONTH_NBR
WHERE
(T.ACCOUNT IS NULL AND T.CURR_NUM IS NULL AND T.MONTH_NBR IS NULL)
 OR N.BANK<>T.BANK
 OR N.BRANCH<>T.BRANCH
 OR N.CATEGORY<>T.CATEGORY
 OR N.INP_DAY<>T.INP_DAY
 OR N.DRAFT_DAY<>T.DRAFT_DAY
 OR N.ODUE_FLAG<>T.ODUE_FLAG
 OR N.INP_BAL<>T.INP_BAL
 OR N.INP_BALORI<>T.INP_BALORI
 OR N.REM_BAL<>T.REM_BAL
 OR N.REM_BALORI<>T.REM_BALORI
 OR N.LAST_PAYMT<>T.LAST_PAYMT
 OR N.INP_TIME<>T.INP_TIME
 OR N.INP_NOINT<>T.INP_NOINT
 OR N.REM_NOINT<>T.REM_NOINT
 OR N.INP_NINT01<>T.INP_NINT01
 OR N.INP_NINT02<>T.INP_NINT02
 OR N.INP_NINT03<>T.INP_NINT03
 OR N.INP_NINT04<>T.INP_NINT04
 OR N.INP_NINT05<>T.INP_NINT05
 OR N.INP_NINT06<>T.INP_NINT06
 OR N.INP_NINT07<>T.INP_NINT07
 OR N.INP_NINT08<>T.INP_NINT08
 OR N.INP_NINT09<>T.INP_NINT09
 OR N.INP_NINT10<>T.INP_NINT10
 OR N.REM_NINT01<>T.REM_NINT01
 OR N.REM_NINT02<>T.REM_NINT02
 OR N.REM_NINT03<>T.REM_NINT03
 OR N.REM_NINT04<>T.REM_NINT04
 OR N.REM_NINT05<>T.REM_NINT05
 OR N.REM_NINT06<>T.REM_NINT06
 OR N.REM_NINT07<>T.REM_NINT07
 OR N.REM_NINT08<>T.REM_NINT08
 OR N.REM_NINT09<>T.REM_NINT09
 OR N.REM_NINT10<>T.REM_NINT10
;

--Step3:
UPDATE dw_sdata.CCB_000_ODUE P 
SET End_Dt=DATE('${TX_DATE_YYYYMMDD}')
FROM T_349
WHERE P.End_Dt=DATE('2100-12-31')
AND P.ACCOUNT=T_349.ACCOUNT
AND P.CURR_NUM=T_349.CURR_NUM
AND P.MONTH_NBR=T_349.MONTH_NBR
;

--Step4:
INSERT  INTO dw_sdata.CCB_000_ODUE SELECT * FROM T_349;

COMMIT;

ENDOFINPUT

  close(VSQL);

  my $RET_CODE = $? >> 8;

  if ( $RET_CODE == 0 ) {
      return 0;
  }
  else {
      return 1;
  }
}

# ------------ main function ------------
sub main
{
   my $ret;
   open(LOGONFILE_H, "${LOGON_FILE}");
   ${LOGON_STR} = <LOGONFILE_H>;
   close(LOGONFILE_H);
   
   # Get the decoded logon string
   my($user,$passwd) = split(',',${LOGON_STR}); 
   #my $decodepasswd = `${AUTO_HOME}/bin/IceCode.exe -d "$passwd" "$user"`;                     
   #${LOGON_STR} = "|vsql -h 192.168.2.44 -p 5433 -d CPCIMDB -U ".$user." -w ".$decodepasswd;

   # Call vsql command to load data
   $ret = run_vsql_command();

   print "run_vsql_command() = $ret";
   return $ret;
}

# ------------ program section ------------
if ( $#ARGV < 0 ) {
   print "Usage: [perl ������ Control_File] (Control_File format: dir.jobnameYYYYMMDD or sysname_jobname_YYYYMMDD.dir) 
";
   print "
";
   exit(1);
}

# Get the first argument
${CONTROL_FILE} = $ARGV[0];

if (${CONTROL_FILE} =~/[0-9]{8}($|\.)/) {
   ${TX_DATE_YYYYMMDD} = substr($&,0,8);
}
else{
   print "Usage: [perl ������ Control_File] (Control_File format: dir.jobnameYYYYMMDD or sysname_jobname_YYYYMMDD.dir) 
";
   print "
";
   exit(1);
}

${TX_MON_DAY_MMDD} = substr(${TX_DATE_YYYYMMDD}, length(${TX_DATE_YYYYMMDD})-4,4);
${TX_DATE} = substr(${TX_DATE_YYYYMMDD}, 0, 4)."-".substr(${TX_DATE_YYYYMMDD}, 4, 2)."-".substr(${TX_DATE_YYYYMMDD}, 6, 2);
open(STDERR, ">&STDOUT");

my $ret = main();

exit($ret);
